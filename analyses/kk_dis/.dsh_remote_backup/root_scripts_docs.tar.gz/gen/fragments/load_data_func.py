def load_data():
    n_repeat = 1
    n_truth_mc = 150000  # intentional truth-MC cap; this is not n_data
    data = {}

    data['data_phi_kk'] = onp.tile(onp.load('data/real_data/phi_kk.npy'), n_repeat)
    data['mc_phi_kk'] = onp.tile(onp.load('data/mc_truth/phi_kk.npy'), n_repeat)
    data['truth_phi_kk'] = data['mc_phi_kk'][0:n_truth_mc * n_repeat]

    data['data_f_kk'] = onp.tile(onp.load('data/real_data/f_kk.npy'), n_repeat)
    data['mc_f_kk'] = onp.tile(onp.load('data/mc_truth/f_kk.npy'), n_repeat)
    data['truth_f_kk'] = data['mc_f_kk'][0:n_truth_mc * n_repeat]

    data['data_phif0_kk'] = onp.tile(onp.load('data/real_data/phif0_kk.npy'), (1, n_repeat, 1))
    data['mc_phif0_kk'] = onp.tile(onp.load('data/mc_truth/phif0_kk.npy'), (1, n_repeat, 1))
    data['truth_phif0_kk'] = data['mc_phif0_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_phif2_kk'] = onp.tile(onp.load('data/real_data/phif2_kk.npy'), (1, n_repeat, 1))
    data['mc_phif2_kk'] = onp.tile(onp.load('data/mc_truth/phif2_kk.npy'), (1, n_repeat, 1))
    data['truth_phif2_kk'] = data['mc_phif2_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_b123_kk'] = onp.tile(onp.load('data/real_data/b123_kk.npy'), n_repeat)
    data['mc_b123_kk'] = onp.tile(onp.load('data/mc_truth/b123_kk.npy'), n_repeat)
    data['truth_b123_kk'] = data['mc_b123_kk'][0:n_truth_mc * n_repeat]

    data['data_b124_kk'] = onp.tile(onp.load('data/real_data/b124_kk.npy'), n_repeat)
    data['mc_b124_kk'] = onp.tile(onp.load('data/mc_truth/b124_kk.npy'), n_repeat)
    data['truth_b124_kk'] = data['mc_b124_kk'][0:n_truth_mc * n_repeat]

    return data
