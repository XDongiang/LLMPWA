def shard_data_distributed(data, mesh):
    jax_data = {}
    for key, value in data.items():
        array = np.asarray(value)
        if array.ndim == 1:
            spec = P('event')
        elif array.ndim == 3:
            spec = P(None, 'event', None)
        else:
            raise ValueError('Unsupported data rank for ' + key + ': ' + str(array.ndim))
        jax_data[key] = device_put(array, NamedSharding(mesh, spec))
    return jax_data
