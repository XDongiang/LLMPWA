def normalize_data(data):
    for var in ('phif0_kk', 'phif2_kk'):
        mc_arr = data['mc_' + var]
        regular = 1.0 / onp.mean(
            onp.sqrt(onp.sum(mc_arr ** 2, axis=-1)), axis=1
        )
        for prefix in ('data_', 'mc_', 'truth_'):
            key = prefix + var
            data[key] = onp.einsum('c,cek->cek', regular, data[key])
    return data
