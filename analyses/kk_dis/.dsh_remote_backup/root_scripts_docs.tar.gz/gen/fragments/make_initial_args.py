
def make_initial_args():
    _data = toml.load("run/free_params.toml")["data"]
    _data.sort(key=lambda x: x["arg_index"])

    args = [d["value"] for d in _data]
    ranges = [d.get("range", [-onp.inf, onp.inf]) for d in _data]
    errors = [d["error"] for d in _data]

    return onp.array(args), onp.array(ranges), onp.array(errors)
