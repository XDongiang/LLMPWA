# Stage: classification

## Prompt

```
预处理规则：
- 普通 resonance：包含 propagators 和 Amplitude 的 resonance，直接作为一个共振/振幅分量参与后续分组。
- shared_state resonance：如果某个 resonance 的 kind = "shared_state"，它不是单个振幅项，而是一个共享物理态容器。必须先把 resonances.<state>.amplitudes 中的每一项展开为一个独立的振幅分量。
- 展开 shared_state 时，分量名称使用 amplitudes[].name；传播子参数来自该 shared_state 的 propagators；A_propagator.Sbc 直接沿用；若 amplitudes[].B_Sbc 存在，则它覆盖 B_propagator.Sbc，作为该分量的 B 传播子 Sbc。
- 展开 shared_state 时，振幅名称使用 amplitudes[].AMP。若 amplitudes[].parameter_ref 指向 shared_amplitude_parameters，则该分量的 const/theta 等振幅参数来自 shared_amplitude_parameters，并且这些分量共享同一组优化参数。
- 对共享参数的处理：parameter_lists 中可以按展开后的分量重复填写共享参数的数值，以便后续向量化计算；但 fixed_parameter 和优化变量语义上只能保留一份共享参数，不能把 K2100_r.const1 和 K2100_l.const1 当成两个独立变量。

任务：
1. 按"传播子类型"（propagator_type）对共振（resonances）进行分组。
    定义：
    - 相似的"A传播子"（A_propagator）必须具有相同的"传播子类型"（propagator_type）。
    - 相似的"B传播子"（B_propagator）必须具有相同的"传播子类型"（propagator_type）。
    组名称：
    将"A传播子"（A_propagator）类型与"B传播子"（B_propagator）类型用下划线（_）组合。示例："TypeA_TypeB"（即"A类型_B类型"）。

2. 因为在计算的时候，同一类型的传播子可以向量化计算，但是不同振幅参数的传播子不能向量化计算。因此按照传播子类型+振幅参数的方式进行分组。
    定义：
    - 具有任务1中定义的相同"A传播子"和"B传播子"类型。
    - 具有相同的振幅名称（AMP的值）。

3. 我们需要参数值的列表，根据任务2的分组结果，输出组内参数的列表。
    定义：
    - 对于每个组合并组内的共振态的参数，输出参数的值列表。
    - 合并的方式为共振态之间相同的参数合并为一个参数，value值组合为列表。
    - 共振态Amplitude参数合并为二维list，例如[[a_resonance_const1, a_resonance_const2], [b_resonance_const1, b_resonance_const2]]。

4. 认真读取toml配置中的fix属性，fix属性是True的变量在程序中的计算是不被优化的。将找到的变量的变量名填入到fixed_parameter表格中。

输出格式：
{{
    "propagator_classification": {{
    "TypeA_TypeB": ["resonance_name_1"（共振名称1）, "resonance_name_2"（共振名称2）],
    "TypeA_TypeC": ["resonance_name_3"（共振名称3）]
    }},
    "amplitude_classification": {{
    "AMP_TypeA_TypeB": ["resonance_name_1"（共振名称1）, "resonance_name_2"（共振名称2）],
    "AMP_TypeA_TypeC": ["resonance_name_3"（共振名称3）]
    }},
    "parameter_lists": {{
    "AMP_TypeA_TypeB": ["mass":[0.980, 1.27], "width":[0.05, 0.15], "const":[0.5, 1.0], "theta":[0.0, 1.57]],
    "AMP_TypeA_TypeC": ["mass":[1.27], "width":[0.15], "const":[1.0], "theta":[1.57]]
    }},
    "fixed_parameter":{{
    "AMP_TypeA_TypeB": ["mass", "const1", "theta1"]
    }}
}}


使用传入的{"arg_index": n}代替parameter_lists中变量的具体值,输出纯json，不要包含注释
 toml 配置：{
  "draw": {
    "extra_sbc": [
      "b123_kk",
      "b124_kk"
    ]
  },
  "fit": {
    "total_frac": 1.1,
    "lambda_tfc": 1000,
    "boundary": true
  },
  "resonances": {
    "phif0_980": {
      "Amplitude": {
        "AMP": "phif0_kk",
        "const1": {
          "value": 0.1,
          "fixed": true,
          "error": 0.0
        },
        "const2": {
          "arg_index": 3
        },
        "theta1": {
          "value": 0.1,
          "fixed": true,
          "error": 0.0
        },
        "theta2": {
          "arg_index": 4
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "flatte980",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 0
          },
          "g_kk": {
            "arg_index": 1
          },
          "rg": {
            "arg_index": 2
          }
        }
      }
    },
    "phif0_1710": {
      "Amplitude": {
        "AMP": "phif0_kk",
        "const1": {
          "arg_index": 7
        },
        "const2": {
          "arg_index": 8
        },
        "theta1": {
          "arg_index": 9
        },
        "theta2": {
          "arg_index": 10
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 5
          },
          "width": {
            "arg_index": 6
          }
        }
      }
    },
    "phif2_1270": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 13
        },
        "const2": {
          "arg_index": 14
        },
        "const3": {
          "arg_index": 15
        },
        "const4": {
          "arg_index": 16
        },
        "const5": {
          "arg_index": 17
        },
        "theta1": {
          "arg_index": 18
        },
        "theta2": {
          "arg_index": 19
        },
        "theta3": {
          "arg_index": 20
        },
        "theta4": {
          "arg_index": 21
        },
        "theta5": {
          "arg_index": 22
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "flatte1270",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 11
          },
          "width": {
            "arg_index": 12
          }
        }
      }
    },
    "phif2_1525": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 25
        },
        "const2": {
          "arg_index": 26
        },
        "const3": {
          "arg_index": 27
        },
        "const4": {
          "arg_index": 28
        },
        "const5": {
          "arg_index": 29
        },
        "theta1": {
          "arg_index": 30
        },
        "theta2": {
          "arg_index": 31
        },
        "theta3": {
          "arg_index": 32
        },
        "theta4": {
          "arg_index": 33
        },
        "theta5": {
          "arg_index": 34
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 23
          },
          "width": {
            "arg_index": 24
          }
        }
      }
    },
    "phif2_2150": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 37
        },
        "const2": {
          "arg_index": 38
        },
        "const3": {
          "arg_index": 39
        },
        "const4": {
          "arg_index": 40
        },
        "const5": {
          "arg_index": 41
        },
        "theta1": {
          "arg_index": 42
        },
        "theta2": {
          "arg_index": 43
        },
        "theta3": {
          "arg_index": 44
        },
        "theta4": {
          "arg_index": 45
        },
        "theta5": {
          "arg_index": 46
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 35
          },
          "width": {
            "arg_index": 36
          }
        }
      }
    },
    "phif2_2340": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 49
        },
        "const2": {
          "arg_index": 50
        },
        "const3": {
          "arg_index": 51
        },
        "const4": {
          "arg_index": 52
        },
        "const5": {
          "arg_index": 53
        },
        "theta1": {
          "arg_index": 54
        },
        "theta2": {
          "arg_index": 55
        },
        "theta3": {
          "arg_index": 56
        },
        "theta4": {
          "arg_index": 57
        },
        "theta5": {
          "arg_index": 58
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 47
          },
          "width": {
            "arg_index": 48
          }
        }
      }
    },
    "phif0_2470": {
      "Amplitude": {
        "AMP": "phif0_kk",
        "const1": {
          "arg_index": 61
        },
        "const2": {
          "arg_index": 62
        },
        "theta1": {
          "arg_index": 63
        },
        "theta2": {
          "arg_index": 64
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 59
          },
          "width": {
            "arg_index": 60
          }
        }
      }
    }
  }
}
```

## Response

```
{
  "propagator_classification": {
    "BW_flatte980": [
      "phif0_980"
    ],
    "BW_BW": [
      "phif0_1710",
      "phif2_1270",
      "phif2_1525",
      "phif2_2150",
      "phif2_2340",
      "phif0_2470"
    ]
  },
  "amplitude_classification": {
    "phif0_kk_BW_flatte980": [
      "phif0_980"
    ],
    "phif0_kk_BW_BW": [
      "phif0_1710",
      "phif0_2470"
    ],
    "phif2_kk_BW_BW": [
      "phif2_1270",
      "phif2_1525",
      "phif2_2150",
      "phif2_2340"
    ]
  },
  "parameter_lists": {
    "phif0_kk_BW_flatte980": {
      "A_mass": [
        1.02
      ],
      "A_width": [
        0.004
      ],
      "B_mass": [
        0
      ],
      "B_g_kk": [
        1
      ],
      "B_rg": [
        2
      ],
      "const": [
        [
          0.1,
          3
        ]
      ],
      "theta": [
        [
          0.1,
          4
        ]
      ]
    },
    "phif0_kk_BW_BW": {
      "A_mass": [
        1.02,
        1.02
      ],
      "A_width": [
        0.004,
        0.004
      ],
      "B_mass": [
        5,
        59
      ],
      "B_width": [
        6,
        60
      ],
      "const": [
        [
          7,
          8
        ],
        [
          61,
          62
        ]
      ],
      "theta": [
        [
          9,
          10
        ],
        [
          63,
          64
        ]
      ]
    },
    "phif2_kk_BW_BW": {
      "A_mass": [
        1.02,
        1.02,
        1.02,
        1.02
      ],
      "A_width": [
        0.004,
        0.004,
        0.004,
        0.004
      ],
      "B_mass": [
        11,
        23,
        35,
        47
      ],
      "B_width": [
        12,
        24,
        36,
        48
      ],
      "const": [
        [
          13,
          14,
          15,
          16,
          17
        ],
        [
          25,
          26,
          27,
          28,
          29
        ],
        [
          37,
          38,
          39,
          40,
          41
        ],
        [
          49,
          50,
          51,
          52,
          53
        ]
      ],
      "theta": [
        [
          18,
          19,
          20,
          21,
          22
        ],
        [
          30,
          31,
          32,
          33,
          34
        ],
        [
          42,
          43,
          44,
          45,
          46
        ],
        [
          54,
          55,
          56,
          57,
          58
        ]
      ]
    }
  },
  "fixed_parameter": {
    "phif0_kk_BW_flatte980": [
      "A_mass",
      "A_width",
      "const1",
      "theta1"
    ],
    "phif0_kk_BW_BW": [
      "A_mass",
      "A_width"
    ],
    "phif2_kk_BW_BW": [
      "A_mass",
      "A_width"
    ]
  }
}
```
