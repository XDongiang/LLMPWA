# Stage: generate_fit_script

## Prompt

```
[system]
You are an interactive physics-coding agent for LLMPWA distributed PWA fit-script generation.

Tools:
- read: read workspace files
- write: write/overwrite workspace files
- shell: light checks only (syntax / import smoke). Do NOT run a full multi-node fit.
- task: call task(action="finish", result=..., outputs={field: path, ...}) to submit.
  The stage is non-interactive (require_approval=false): finish is accepted immediately,
  so verify the deliverable yourself before finishing.

Hard rules:
1. Write the deliverable to **run/fit_script.py**.
2. Reuse **run/base_functions.py** and **run/likelihood_function.py** — do not re-implement
   dplex_*, BW/flatte*, load_data / normalize_data / shard_data_distributed,
   make_initial_args / save_result, or the likelihood body.
3. Build a multi-process JAX event-sharded Newton-CG fit main:
   init_distributed → mesh → load/normalize/shard → jit likelihood/grad/HVP →
   SciPy Newton-CG on all processes → chief-only I/O.
4. Adapt call signatures to THIS analysis's actual APIs (read the two modules first).
5. Stay inside the analysis workspace; do not search or depend on external example scripts.
6. No markdown fences in the saved .py.
7. Prefer compact code; no long #==== banner comments.
8. After writing, run a light syntax/import smoke (not a full minimize) if feasible,
   then task.finish.


[user]
## Goal
Generate the distributed fit entry script **run/fit_script.py**.

It is the main program for multi-process JAX data-parallel Newton-CG fitting.
Helpers and likelihood already exist; this file only wires them together.

## Required workflow
1. Read (workspace only):
   - run/base_functions.py
   - run/likelihood_function.py
2. Implement **run/fit_script.py** using the architecture below and local module APIs.
3. Optional light smoke (from analysis workdir):
   - `python -c "import ast; ast.parse(open('run/fit_script.py').read())"`
   - do **not** launch multi-node training or a long minimize
4. Finish:
   ```
   task(
     action="finish",
     result=<1-10 lines: path, key steps, smoke status>,
     outputs={"all": "run/fit_script.py"}
   )
   ```

## Module contracts (verify with read; adapt if signatures differ)

### run/base_functions.py (MUST import; do not duplicate)
Expected / typical symbols:
- path setup already chdirs to analysis root when base_functions is imported
- `setup_logging()`
- `make_initial_args() -> (args, ranges, errors)`  (host numpy)
- `save_result(args, errors, path=...)`
- `load_data() -> dict` host arrays with keys data_/mc_/truth_*
- `normalize_data(data) -> data`
- `shard_data_distributed(data, mesh) -> jax_data`
- jax/numpy helpers: `np` (jax.numpy), `onp`, `device_put`, `grad`, `jit`, `jvp`,
  `config`, `NamedSharding`, `P`; fit_script may also import `minimize` / `jax` / `Mesh`
  itself if missing from base_functions

Current assembled helpers (for reference):
```python
import json
import logging
import logging.config
import os
import toml
# must set before importing jax
os.environ["XLA_PYTHON_CLIENT_PREALLOCATE"] = "false"
import time
import numpy as onp
from functools import partial
from scipy.optimize import minimize

import jax.numpy as np
from jax import device_put, grad, jit, vmap, jvp
from jax import config
from jax.sharding import NamedSharding, PartitionSpec as P




import sys
foo_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(foo_path)
sys.path.append(foo_path)




def setup_logging():
    """Setup logging configuration"""
    with open("config/logconfig_fit.json", "r") as config_file:
        LOGGING_CONFIG = json.load(config_file)
        logging.config.dictConfig(LOGGING_CONFIG)
    return logging.getLogger("fit")




def dplex_deinsum(subscript, aa, bb):
    real = np.einsum(subscript, aa[0], bb[0]) - np.einsum(subscript, aa[1], bb[1])
    imag = np.einsum(subscript, aa[0], bb[1]) + np.einsum(subscript, aa[1], bb[0])
    return np.stack([real, imag], axis=0)

def dplex_deinsum_ord(subscript, aa, bb):
    real = np.einsum(subscript, aa, bb[0])
    imag = np.einsum(subscript, aa, bb[1])
    return np.stack([real, imag], axis=0)

def dplex_dabs(aa):
    return aa[0]**2 + aa[1]**2 # 因为是纵向叠加所以aa[0]是纵向上第一个数组

def dplex_dtomine(aa):
    return np.stack([np.real(aa), np.imag(aa)], axis=0) # 组合而成的数组 axis=0 的第一个数组为实部，第二个数组为虚部

def dplex_dconstruct(aa, bb):
    return np.stack([aa, bb], axis=0) # 纵向叠加数组 第一维为实部，第二维为虚部

def dplex_ddivide(a, bb):
    real = a * bb[0] / dplex_dabs(bb)
    imag = -a * bb[1] / dplex_dabs(bb)
    return np.stack([real, imag], axis=0)



# Physics calculation functions (resonance shape functions)
# Provided by the user for each analysis. Copy this file to your analysis
# directory as physics_functions.py and keep only the functions you need.
# ==============================================================================




def BW(m_, w_, Sbc):
    l = (Sbc.shape)[0]
    temp = dplex_dconstruct(m_*m_ - Sbc, -m_*w_*np.ones(l))
    return dplex_ddivide(1.0, temp)


def BW_relativity(m_, w_, Sbc):
    gamma = np.sqrt(m_*m_*(m_*m_+w_*w_))
    k = np.sqrt(2*np.sqrt(2)*m_*np.abs(w_)*gamma/np.pi/np.sqrt(m_*m_+gamma))
    l = (Sbc.shape)[0]
    temp = dplex_dconstruct(m_*m_ - Sbc, -m_*w_*np.ones(l))
    return dplex_ddivide(k, temp)


def flatte980(m_, g_pipi, rg, Sbc):
    g_kk = rg * g_pipi
    m_k = 0.493677
    m_pi = 0.13957061
    rho_kk = np.sqrt(np.abs(1 - 4*m_k*m_k / Sbc))
    rho_pipi = np.sqrt(np.abs(1 - 4*m_pi*m_pi / Sbc))
    tmp_A = dplex_dconstruct(m_**2 - Sbc, -1*(g_pipi*rho_pipi + g_kk*rho_kk))
    return dplex_ddivide(1.0, tmp_A)


def flatte1270(m_, w_, Sbc):
    rm = m_ * m_
    gr = m_ * w_
    q2r = 0.25 * rm - 0.0194792
    b2r = q2r * (q2r + 0.1825) + 0.033306
    g11270 = gr * b2r / np.power(q2r, 2.5)
    q2 = 0.25 * Sbc - 0.0194792
    b2 = q2 * (q2 + 0.1825) + 0.033306
    g1 = g11270 * np.power(q2, 2.5) / b2
    tmp = dplex_dconstruct(Sbc - rm, g1)
    return dplex_ddivide(gr, tmp)


def flatte500(m_, b1, b2, b3, b4, b5, Sbc):
    m2 = m_*m_
    rp = 0.139556995
    mpi2d2 = 0.009739946882
    cro1 = np.sqrt(np.abs((Sbc-(2*rp)**2)*Sbc))/Sbc
    cro2 = np.sqrt(np.abs((m2-(2*rp)**2)*m2))/m2
    pip1 = np.sqrt(np.abs(1.0 - 0.3116765584/Sbc))/(1.0+np.exp(9.8-3.5*Sbc))
    pip2 = np.sqrt(np.abs(1.0 - 0.3116765584/m2))/(1.0+np.exp(9.8-3.5*m2))
    cgam1 = m_*(b1+b2*Sbc)*(Sbc-mpi2d2)/(m2-mpi2d2)*np.exp(-(Sbc-m2)/b3)*cro1/cro2
    cgam2 = m_*b4*pip1/pip2
    tmp = dplex_dconstruct(m2-Sbc, -b5*(cgam1+cgam2))
    return dplex_ddivide(1.0, tmp)



def make_initial_args():
    _data = toml.load("run/free_params.toml")["data"]
    _data.sort(key=lambda x: x["arg_index"])

    args = [d["value"] for d in _data]
    ranges = [d.get("range", [-onp.inf, onp.inf]) for d in _data]
    errors = [d["error"] for d in _data]

    return onp.array(args), onp.array(ranges), onp.array(errors)



def save_result(args, errors, path="output/free_params_fitted.toml"):
    _data = toml.load("run/free_params.toml")["data"]
    _data.sort(key=lambda x: x["arg_index"])

    for i, d in enumerate(_data):
        d["value"] = float(args[i])
        d["error"] = float(errors[i])

    with open(path, "w") as f:
        toml.dump({"data": _data}, f)


def load_data():
    n_repeat = 1
    n_truth_mc = 150000  # intentional truth-MC cap; this is not n_data
    data = {}

    data['data_phi_kk'] = onp.tile(onp.load('data/real_data/phi_kk.npy'), n_repeat)
    data['mc_phi_kk'] = onp.tile(onp.load('data/mc_truth/phi_kk.npy'), n_repeat)
    data['truth_phi_kk'] = data['mc_phi_kk'][0:n_truth_mc * n_repeat]

    data['data_f_kk'] = onp.tile(onp.load('data/real_data/f_kk.npy'), n_repeat)
    data['mc_f_kk'] = onp.tile(onp.load('data/mc_truth/f_kk.npy'), n_repeat)
    data['truth_f_kk'] = data['mc_f_kk'][0:n_truth_mc * n_repeat]

    data['data_phif0_kk'] = onp.tile(onp.load('data/real_data/phif0_kk.npy'), (1, n_repeat, 1))
    data['mc_phif0_kk'] = onp.tile(onp.load('data/mc_truth/phif0_kk.npy'), (1, n_repeat, 1))
    data['truth_phif0_kk'] = data['mc_phif0_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_phif2_kk'] = onp.tile(onp.load('data/real_data/phif2_kk.npy'), (1, n_repeat, 1))
    data['mc_phif2_kk'] = onp.tile(onp.load('data/mc_truth/phif2_kk.npy'), (1, n_repeat, 1))
    data['truth_phif2_kk'] = data['mc_phif2_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_b123_kk'] = onp.tile(onp.load('data/real_data/b123_kk.npy'), n_repeat)
    data['mc_b123_kk'] = onp.tile(onp.load('data/mc_truth/b123_kk.npy'), n_repeat)
    data['truth_b123_kk'] = data['mc_b123_kk'][0:n_truth_mc * n_repeat]

    data['data_b124_kk'] = onp.tile(onp.load('data/real_data/b124_kk.npy'), n_repeat)
    data['mc_b124_kk'] = onp.tile(onp.load('data/mc_truth/b124_kk.npy'), n_repeat)
    data['truth_b124_kk'] = data['mc_b124_kk'][0:n_truth_mc * n_repeat]

    return data


def normalize_data(data):
    for var in ('phif0_kk', 'phif2_kk'):
        mc_arr = data['mc_' + var]
        regular = 1.0 / onp.mean(
            onp.sqrt(onp.sum(mc_arr ** 2, axis=-1)), axis=1
        )
        for prefix in ('data_', 'mc_', 'truth_'):
            key = prefix + var
            data[key] = onp.einsum('c,cek->cek', regular, data[key])
    return data


def shard_data_distributed(data, mesh):
    jax_data = {}
    for key, value in data.items():
        array = np.asarray(value)
        if array.ndim == 1:
            spec = P('event')
        elif array.ndim == 3:
            spec = P(None, 'event', None)
        else:
            raise ValueError('Unsupported data rank for ' + key + ': ' + str(array.ndim))
        jax_data[key] = device_put(array, NamedSharding(mesh, spec))
    return jax_data



```

### run/likelihood_function.py (MUST import)
Expected API (adapt to actual definitions):
- `combined_likelihood(args, data_or_jax_data) -> scalar`
  (data_size is typically taken from data_or_jax_data inside, or use
   `make_distributed_likelihood(data_size)` if that factory is preferred)
- `hvp_combined_likelihood(args, vector, data_or_jax_data) -> vector`
  OR build HVP via `jvp(grad(...), ...)` when needed for non-addressable sharded data

Likelihood body reference (do not paste wholesale; only for call signatures):
```python
from base_functions import (
    BW,
    dplex_dabs,
    dplex_dconstruct,
    dplex_deinsum,
    dplex_deinsum_ord,
    flatte1270,
    flatte980,
    jvp,
    grad,
    make_initial_args,
    np,
    onp,
)


GAUSSIAN_CONSTRAINTS = (
    (0, 0.98, 10.0),
    (5, 1.704, 1.0),
    (6, 0.123, 1.0),
    (11, 1.2755, 1.0),
    (12, 0.1867, 1.0),
    (23, 1.517, 1.0),
    (24, 0.086, 1.0),
    (35, 2.157, 1.0),
    (36, 0.152, 1.0),
    (47, 2.345, 0.01),
    (48, 0.322, 1.0),
    (59, 2.47, 0.007),
    (60, 0.075, 0.011),
)


def extract_parameters(args):
    args = np.asarray(args)
    return {
        "f0_980": {
            "mass": args[0], "g_pipi": args[1], "rg": args[2],
            "const": np.asarray([0.1, args[3]]),
            "theta": np.asarray([0.1, args[4]]),
        },
        "f0_bw": {
            "mass": args[np.asarray([5, 59])],
            "width": args[np.asarray([6, 60])],
            "const": np.stack((args[np.asarray([7, 8])], args[np.asarray([61, 62])])),
            "theta": np.stack((args[np.asarray([9, 10])], args[np.asarray([63, 64])])),
        },
        "f2_1270": {
            "mass": args[11], "width": args[12],
            "const": args[13:18], "theta": args[18:23],
        },
        "f2_bw": {
            "mass": args[np.asarray([23, 35, 47])],
            "width": args[np.asarray([24, 36, 48])],
            "const": np.stack((args[25:30], args[37:42], args[49:54])),
            "theta": np.stack((args[30:35], args[42:47], args[54:59])),
        },
    }


def _propagator_product(phi_mass, phi_width, phi_s, f_propagators):
    phi_prop = BW(phi_mass, phi_width, phi_s)
    n_states = f_propagators.shape[1]
    phi_props = np.broadcast_to(phi_prop[:, None, :], (2, n_states, phi_s.shape[0]))
    return dplex_deinsum("le,le->le", phi_props, f_propagators)


def _coupled_components(tensor, const, theta, propagators):
    couplings = dplex_dconstruct(const, theta)
    weighted = dplex_deinsum_ord("iek,li->lek", tensor, couplings)
    return dplex_deinsum("lek,le->lek", weighted, propagators)


def _category_components(params, phi_s, f_s, f0_tensor, f2_tensor):
    phi_mass = 1.02
    phi_width = 0.004

    p = params["f0_980"]
    f_prop = flatte980(p["mass"], p["g_pipi"], p["rg"], f_s)[:, None, :]
    prop = _propagator_product(phi_mass, phi_width, phi_s, f_prop)
    f0_980 = _coupled_components(f0_tensor, p["const"][None, :], p["theta"][None, :], prop)

    p = params["f0_bw"]
    f_prop = np.stack([BW(p["mass"][i], p["width"][i], f_s) for i in range(2)], axis=1)
    prop = _propagator_product(phi_mass, phi_width, phi_s, f_prop)
    f0_bw = _coupled_components(f0_tensor, p["const"], p["theta"], prop)

    p = params["f2_1270"]
    f_prop = flatte1270(p["mass"], p["width"], f_s)[:, None, :]
    prop = _propagator_product(phi_mass, phi_width, phi_s, f_prop)
    f2_1270 = _coupled_components(f2_tensor, p["const"][None, :], p["theta"][None, :], prop)

    p = params["f2_bw"]
    f_prop = np.stack([BW(p["mass"][i], p["width"][i], f_s) for i in range(3)], axis=1)
    prop = _propagator_product(phi_mass, phi_width, phi_s, f_prop)
    f2_bw = _coupled_components(f2_tensor, p["const"], p["theta"], prop)
    return f0_980, f0_bw, f2_1270, f2_bw


def _total_amplitude(components):
    return sum(np.sum(component, axis=1) for component in components)


def _components_for_prefix(args, data, prefix):
    params = extract_parameters(args)
    return _category_components(
        params,
        np.asarray(data[prefix + "phi_kk"]),
        np.asarray(data[prefix + "f_kk"]),
        np.asarray(data[prefix + "phif0_kk"]),
        np.asarray(data[prefix + "phif2_kk"]),
    )


def event_intensity(args, data, prefix):
    total = _total_amplitude(_components_for_prefix(args, data, prefix))
    return np.sum(dplex_dabs(total), axis=-1)


def fraction_values(args, data):
    components = _components_for_prefix(args, data, "truth_")
    denominator = np.sum(dplex_dabs(_total_amplitude(components)))
    denominator = np.maximum(denominator, np.finfo(np.asarray(denominator).dtype).tiny)
    fractions = np.stack([np.sum(dplex_dabs(component)) / denominator for component in components])
    return fractions


def gaussian_penalty(args):
    args = np.asarray(args)
    return sum((args[index] - center) ** 2 / (2.0 * sigma ** 2)
               for index, center, sigma in GAUSSIAN_CONSTRAINTS)


def data_likelihood_kk(args, data_or_jax_data):
    intensity = event_intensity(args, data_or_jax_data, "data_")
    tiny = np.finfo(intensity.dtype).tiny
    fractions = fraction_values(args, data_or_jax_data)
    fraction_penalty = 1000.0 * (np.sum(fractions) - 1.1) ** 2
    return -np.sum(np.log(np.maximum(intensity, tiny))) + fraction_penalty + gaussian_penalty(args)


def mc_likelihood_kk(args, data_or_jax_data):
    intensity = event_intensity(args, data_or_jax_data, "mc_")
    return np.mean(intensity)


def combined_likelihood(args, data_or_jax_data):
    data_size = data_or_jax_data["data_phi_kk"].shape[0]
    mc_norm = mc_likelihood_kk(args, data_or_jax_data)
    tiny = np.finfo(mc_norm.dtype).tiny
    return data_likelihood_kk(args, data_or_jax_data) + data_size * np.log(np.maximum(mc_norm, tiny))


def make_distributed_likelihood(data_size):
    def likelihood(args, data_or_jax_data):
        mc_norm = mc_likelihood_kk(args, data_or_jax_data)
        tiny = np.finfo(mc_norm.dtype).tiny
        return data_likelihood_kk(args, data_or_jax_data) + data_size * np.log(np.maximum(mc_norm, tiny))
    return likelihood


def hvp_combined_likelihood(args, vector, data_or_jax_data):
    gradient = grad(combined_likelihood, argnums=0)
    return jvp(lambda x: gradient(x, data_or_jax_data), (args,), (vector,))[1]


def _load_smoke_subset(n_data=128, n_mc=512, n_truth=256):
    data = {}
    for var in ("phi_kk", "f_kk", "b123_kk", "b124_kk"):
        real = onp.load("data/real_data/" + var + ".npy", mmap_mode="r")
        mc = onp.load("data/mc_truth/" + var + ".npy", mmap_mode="r")
        data["data_" + var] = onp.asarray(real[:n_data])
        data["mc_" + var] = onp.asarray(mc[:n_mc])
        data["truth_" + var] = onp.asarray(mc[:n_truth])
    for var in ("phif0_kk", "phif2_kk"):
        real = onp.load("data/real_data/" + var + ".npy", mmap_mode="r")
        mc = onp.load("data/mc_truth/" + var + ".npy", mmap_mode="r")
        data["data_" + var] = onp.asarray(real[:, :n_data, :])
        data["mc_" + var] = onp.asarray(mc[:, :n_mc, :])
        data["truth_" + var] = onp.asarray(mc[:, :n_truth, :])
        regular = 1.0 / onp.mean(onp.sqrt(onp.sum(data["mc_" + var] ** 2, axis=-1)), axis=1)
        for prefix in ("data_", "mc_", "truth_"):
            data[prefix + var] = onp.einsum("i,iek->iek", regular, data[prefix + var])
    return data


if __name__ == "__main__":
    initial_args, _, _ = make_initial_args()
    smoke_data = _load_smoke_subset()
    data_value = data_likelihood_kk(initial_args, smoke_data)
    mc_value = mc_likelihood_kk(initial_args, smoke_data)
    combined_value = combined_likelihood(initial_args, smoke_data)
    print("n_args =", initial_args.size)
    print("data_size =", smoke_data["data_phi_kk"].shape[0])
    print("data_likelihood =", float(data_value))
    print("mc_likelihood =", float(mc_value))
    print("combined_likelihood =", float(combined_value))

```

## Required architecture for run/fit_script.py

Event-level data parallel + Newton-CG:
- each process/GPU holds an event shard
- likelihood / grad / HVP reduce across devices via XLA all-reduce on sharded arrays
- SciPy Newton-CG outer loop runs on every process with the same inputs and collective order
- only process 0 writes logs/results

### 1) init_distributed()
```python
def init_distributed():
    coordinator = os.environ.get("JAX_COORDINATOR_ADDRESS", "")
    num_processes = int(os.environ.get("JAX_NUM_PROCESSES", 1))
    process_id = int(os.environ.get("JAX_PROCESS_ID", 0))
    if num_processes > 1:
        jax.distributed.initialize(
            coordinator_address=coordinator,
            num_processes=num_processes,
            process_id=process_id,
        )
    return num_processes, process_id
```

### 2) build_mesh()
```python
def build_mesh():
    return Mesh(jax.devices(), axis_names=("event",))
```

### 3) main() outline
1. `num_processes, process_id = init_distributed()`; `is_chief = (process_id == 0)`
2. `config.update("jax_enable_x64", True)`
3. `logger = setup_logging()`; only chief logs status / process counts
4. `data = load_data(); data = normalize_data(data)`
5. `data_size = len(data["data_phi_kk"])` (or the real-data 1D event key present)
6. `mesh = build_mesh()`
7. Inside mesh context (`with jax.set_mesh(mesh):` or equivalent for this JAX version):
   - `jax_data = shard_data_distributed(data, mesh)`
   - Build callable NLL over `(args, jax_data)` from likelihood_function
   - **Do not** close over non-addressable sharded arrays inside jit if multi-process
     forbids it; pass `jax_data` as an explicit argument.
   - Grad: `grad(nll, argnums=0)` (differentiate only args)
   - HVP: prefer jvp-of-grad with zero data tangent, e.g.
     `zero_data = jax.tree.map(np.zeros_like, jax_data)` then
     `jvp(grad_fn, (x, jax_data), (v, zero_data))[1]`
     (or use `hvp_combined_likelihood` if it already matches this contract)
   - `args_list, _, _ = make_initial_args()`
   - replicate args: `device_put(np.asarray(args_list), NamedSharding(mesh, P()))`
   - `jit_likelihood = jit(nll)`, `jit_grad = jit(grad(...))`, `jit_hvp = jit(hvp...)`
   - smoke: one likelihood eval + one HVP; chief logs scalars/shapes
   - SciPy:
     ```python
     result = minimize(
         fun=lambda x: float(jit_likelihood(np.asarray(x), jax_data)),
         x0=onp.asarray(args_list),
         jac=lambda x: onp.array(jit_grad(np.asarray(x), jax_data)),
         hessp=lambda x, p: onp.array(jit_hvp(np.asarray(x), np.asarray(p), jax_data)),
         method="Newton-CG",
         callback=my_callback,
         options={"disp": False, "xtol": 1e-8},
     )
     ```
   - **All processes** run the same minimize loop (identical collective order)
   - callback: every process evaluates likelihood (sync); only chief logs
   - After optimize: build Hessian columns via HVP on all processes;
     `ferror = sqrt(diag(inv(H)))`
   - **Only chief** writes:
     - `output/fit/fit_result_values.npy`
     - `output/fit/fit_result_errors.npy`
     - `save_result(result.x, ferror, "output/fit/free_params_fitted.toml")`
8. `return 0`
9. `if __name__ == "__main__": raise SystemExit(main())`

## Import / path policy for run/fit_script.py
Recommended pattern (adjust to what base_functions already does):
```python
import os
import sys
import time

_here = os.path.dirname(os.path.abspath(__file__))
_root = os.path.dirname(_here)
os.chdir(_root)
if _root not in sys.path:
    sys.path.insert(0, _root)
if _here not in sys.path:
    sys.path.insert(0, _here)

os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
from jax import config, grad, jit, jvp, device_put
from jax.sharding import Mesh, NamedSharding, PartitionSpec as P
from scipy.optimize import minimize
import numpy as onp

from base_functions import (
    setup_logging,
    make_initial_args,
    save_result,
    load_data,
    normalize_data,
    shard_data_distributed,
    # plus any needed aliases such as np
)
from likelihood_function import (
    combined_likelihood,
    # hvp_combined_likelihood and/or make_distributed_likelihood if useful
)
```

Do **not** redefine physics or likelihood bodies. Only write distributed main orchestration.

## Deliverables checklist
- [ ] run/fit_script.py complete, importable, with main()
- [ ] uses base_functions data I/O + params I/O
- [ ] uses likelihood_function for NLL / HVP
- [ ] multi-process-safe: all ranks minimize; chief-only file writes
- [ ] no dependency on files outside this analysis workspace
- [ ] task.finish with outputs={"all": "run/fit_script.py"}


## Required stage outputs (write these exact paths before task.finish)
- all → run/fit_script.py

When finishing multi-file stages, call:
task(action='finish', result=<summary or primary text>, outputs={field: relative_path, ...})
Paths in outputs must match the list above. The framework will harvest file contents into the corresponding stage output fields.
```

## Response

```
Wrote run/fit_script.py with distributed initialization, event mesh/sharding, explicit-data JAX likelihood/gradient/HVP, synchronized Newton-CG execution on every rank, Hessian-based errors, and chief-only output. AST syntax smoke passed.
```
