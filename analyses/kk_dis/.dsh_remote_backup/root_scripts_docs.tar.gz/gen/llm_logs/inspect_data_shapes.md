# Stage: inspect_data_shapes

## Prompt

```
[system]
You are a data-preprocessing agent in an LLMPWA analysis workspace.

Your job:
1. Inspect real/mc npy data shapes from the stripped resonance config.
2. Generate three pure-Python fragment files for the distributed fit pipeline:
   - load_data()
   - normalize_data(data)
   - shard_data_distributed(data, mesh)

Available tools:
- read: read a text file under the workspace
- write: write/overwrite a text file
- shell: run a shell command (cwd is the analysis workdir)
- task: meta control. Call task(action="finish", result=..., outputs={field: path, ...})
  to submit. The stage is non-interactive (require_approval=false): finish is accepted
  immediately, so verify files yourself before finishing.

Rules:
1. Prefer tools over guessing. Read configs / use numpy for shapes.
2. Write each declared output path exactly (framework injects the path list).
3. Generated .py fragments: function bodies only (or bare defs). No markdown fences.
   Do **not** add import/from statements in fragments — symbols come from
   COMMON_UTILITIES (see task prompt). Shell one-liners for inspection may import freely.
4. Do not run heavy fits; light syntax checks with ast.parse are OK.
5. Write the shape report to gen/fragments/data_shapes_report.txt via the write tool.
   That file is output.all. task.finish(result=...) must be a short summary only —
   do not put the full report body in result (framework harvests the written file).
6. truth_* uses a compute/memory cap: default n_truth_mc=150000 (slice first
   n_truth_mc*n_repeat of mc_*). This is not real-data n_data; still report n_data
   from shapes for data_size later.
7. Always finish with task(action="finish", result=<short summary>,
   outputs={all, load_data, normalize_data, shard_data_distributed: paths}).
8. Stay inside the workspace.


[user]
## Goal
Build the data-preprocessing stage for this distributed fit:
1. Inspect npy shapes for all needed variables.
2. Generate three function fragments used by the fit script:
   - load_data()
   - normalize_data(data)
   - shard_data_distributed(data, mesh)

Reference semantics (adapt names/paths to THIS analysis; do not invent vars):
- load_data: load real_data + mc_truth npy for each sbc/amp var; tile with n_repeat;
  create truth_* by slicing mc_* along the event axis to the **first
  n_truth_mc * n_repeat** events. Default **n_truth_mc = 150000** — this is an
  intentional cap on truth-MC compute/memory (not equal to real-data n_data).
  If mc event count < n_truth_mc * n_repeat, slice to available length (or clamp).
- normalize_data: for multi-component amplitude arrays (phif*-style), compute
  regular factors from mc arrays and einsum-scale data/mc/truth.
- shard_data_distributed: convert to jnp arrays and device_put with NamedSharding:
  1D event arrays → P("event"); 3D (channels, events, components) → P(None, "event", None).

## Inputs already available
- Stripped resonance config:
  path: gen/fragments/stripped_config.toml

```toml
{
  "draw": {
    "extra_sbc": [
      "b123_kk",
      "b124_kk"
    ]
  },
  "fit": {
    "total_frac": 1.1,
    "lambda_tfc": 1000,
    "boundary": true
  },
  "resonances": {
    "phif0_980": {
      "Amplitude": {
        "AMP": "phif0_kk",
        "const1": {
          "value": 0.1,
          "fixed": true,
          "error": 0.0
        },
        "const2": {
          "arg_index": 3
        },
        "theta1": {
          "value": 0.1,
          "fixed": true,
          "error": 0.0
        },
        "theta2": {
          "arg_index": 4
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "flatte980",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 0
          },
          "g_kk": {
            "arg_index": 1
          },
          "rg": {
            "arg_index": 2
          }
        }
      }
    },
    "phif0_1710": {
      "Amplitude": {
        "AMP": "phif0_kk",
        "const1": {
          "arg_index": 7
        },
        "const2": {
          "arg_index": 8
        },
        "theta1": {
          "arg_index": 9
        },
        "theta2": {
          "arg_index": 10
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 5
          },
          "width": {
            "arg_index": 6
          }
        }
      }
    },
    "phif2_1270": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 13
        },
        "const2": {
          "arg_index": 14
        },
        "const3": {
          "arg_index": 15
        },
        "const4": {
          "arg_index": 16
        },
        "const5": {
          "arg_index": 17
        },
        "theta1": {
          "arg_index": 18
        },
        "theta2": {
          "arg_index": 19
        },
        "theta3": {
          "arg_index": 20
        },
        "theta4": {
          "arg_index": 21
        },
        "theta5": {
          "arg_index": 22
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "flatte1270",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 11
          },
          "width": {
            "arg_index": 12
          }
        }
      }
    },
    "phif2_1525": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 25
        },
        "const2": {
          "arg_index": 26
        },
        "const3": {
          "arg_index": 27
        },
        "const4": {
          "arg_index": 28
        },
        "const5": {
          "arg_index": 29
        },
        "theta1": {
          "arg_index": 30
        },
        "theta2": {
          "arg_index": 31
        },
        "theta3": {
          "arg_index": 32
        },
        "theta4": {
          "arg_index": 33
        },
        "theta5": {
          "arg_index": 34
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 23
          },
          "width": {
            "arg_index": 24
          }
        }
      }
    },
    "phif2_2150": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 37
        },
        "const2": {
          "arg_index": 38
        },
        "const3": {
          "arg_index": 39
        },
        "const4": {
          "arg_index": 40
        },
        "const5": {
          "arg_index": 41
        },
        "theta1": {
          "arg_index": 42
        },
        "theta2": {
          "arg_index": 43
        },
        "theta3": {
          "arg_index": 44
        },
        "theta4": {
          "arg_index": 45
        },
        "theta5": {
          "arg_index": 46
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 35
          },
          "width": {
            "arg_index": 36
          }
        }
      }
    },
    "phif2_2340": {
      "Amplitude": {
        "AMP": "phif2_kk",
        "const1": {
          "arg_index": 49
        },
        "const2": {
          "arg_index": 50
        },
        "const3": {
          "arg_index": 51
        },
        "const4": {
          "arg_index": 52
        },
        "const5": {
          "arg_index": 53
        },
        "theta1": {
          "arg_index": 54
        },
        "theta2": {
          "arg_index": 55
        },
        "theta3": {
          "arg_index": 56
        },
        "theta4": {
          "arg_index": 57
        },
        "theta5": {
          "arg_index": 58
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 47
          },
          "width": {
            "arg_index": 48
          }
        }
      }
    },
    "phif0_2470": {
      "Amplitude": {
        "AMP": "phif0_kk",
        "const1": {
          "arg_index": 61
        },
        "const2": {
          "arg_index": 62
        },
        "theta1": {
          "arg_index": 63
        },
        "theta2": {
          "arg_index": 64
        }
      },
      "propagators": {
        "A_propagator": {
          "propagator_type": "BW",
          "Sbc": "phi_kk",
          "mass": {
            "value": 1.02,
            "fixed": true
          },
          "width": {
            "value": 0.004,
            "fixed": true
          }
        },
        "B_propagator": {
          "propagator_type": "BW",
          "Sbc": "f_kk",
          "mass": {
            "arg_index": 59
          },
          "width": {
            "arg_index": 60
          }
        }
      }
    }
  }
}
```

- Variable lists from config_strip:
  all_sbc = phi_kk

f_kk
  all_amp = phif0_kk

phif2_kk
  all_sbc_amp = {
  "phif0_kk": [
    "{'sbc': 'phi_kk', 'propagator_type': 'BW'}",
    "{'sbc': 'f_kk', 'propagator_type': 'flatte980'}",
    "{'sbc': 'f_kk', 'propagator_type': 'BW'}"
  ],
  "phif2_kk": [
    "{'sbc': 'phi_kk', 'propagator_type': 'BW'}",
    "{'sbc': 'f_kk', 'propagator_type': 'flatte1270'}",
    "{'sbc': 'f_kk', 'propagator_type': 'BW'}"
  ]
}

### Shared imports already provided by the assembled fit script
(COMMON_UTILITIES — do **not** re-import these in fragments; use the names as-is)

```python
import json
import logging
import logging.config
import os
import toml
# must set before importing jax
os.environ["XLA_PYTHON_CLIENT_PREALLOCATE"] = "false"
import time
import numpy as onp
from functools import partial
from scipy.optimize import minimize

import jax.numpy as np
from jax import device_put, grad, jit, vmap, jvp
from jax import config
from jax.sharding import NamedSharding, PartitionSpec as P



```

Import policy for the three `.py` fragments:
- **No** `import` / `from ... import ...` lines in fragment files.
- Fragments are later concatenated after COMMON_UTILITIES, so these names are in scope:
  - `onp` — NumPy (host arrays, load/tile/normalize)
  - `np` — `jax.numpy` (device arrays; **not** `jnp`)
  - `device_put`, `NamedSharding`, `P` (`PartitionSpec as P`)
  - plus other COMMON_UTILITIES symbols if needed
- Shell inspection of npy shapes may use a temporary `import numpy as np` in the
  shell snippet only; that is not part of the saved fragments.

## Needed data files
From stripped_config / all_sbc / all_amp, unique variable names include:
1. Every propagator `Sbc` value (e.g. phi_kk, f_kk)
2. Every amplitude `AMP` value (e.g. phif0_kk, phif2_kk)
3. Optional: `draw.extra_sbc` if present

For each var, conventionally:
- data/real_data/{var}.npy
- data/mc_truth/{var}.npy

Also note related files if present (report only; load_data usually uses real_data + mc_truth):
- data/draw_data/{var}.npy
- data/draw_mc/{var}.npy
- data/weight/*

If a listed var has no matching npy under data/, mark MISSING in the report.

## Required procedure
1. Extract unique sbc / amp names from stripped_config / lists above.
2. shell/list data/ candidates; use numpy (mmap) to print shape+dtype for each needed npy.
   Record real_data event counts (n_data) for the report / later data_size usage, and
   mc_truth event counts. All real_data event lengths for the same analysis should agree;
   if not, report the inconsistency.
3. Write the shape report **once** with the write tool to:
   gen/fragments/data_shapes_report.txt
   Contents: unique vars; table path/shape/dtype/MISSING; n_data; mc sizes;
   chosen n_truth_mc (default 150000); short summary.
   This file is the authoritative stage output field `all`. Do **not** rely on
   task.finish(result=...) to carry the report body.
4. Generate three Python fragments (no markdown fences, no #=== section banners):

   a) gen/fragments/load_data_func.py
      - def load_data(): ... only (no imports)
      - Use **onp** from COMMON_UTILITIES (host numpy)
      - Load only vars that exist; keys like data_{var}, mc_{var}, truth_{var}
      - n_repeat = 1 by default
      - n_truth_mc = 150000 by default  # cap truth-MC size for cost/memory
        (name the constant; optional one-line comment that it is NOT n_data)
      - 1D sbc: onp.tile(onp.load(...), n_repeat)
      - multi-dim amp: onp.tile(onp.load(...), (1, n_repeat, 1)) when rank-3
      - truth_* = mc_* sliced on the **event axis** to length n_truth_mc * n_repeat
        (1D: mc[0:n_truth_mc*n_repeat]; rank-3: mc[:, 0:n_truth_mc*n_repeat, ...])
      - Prefer a named constant over a bare magic number, e.g.:
          n_truth_mc = 150000
          data['truth_phi_kk'] = data['mc_phi_kk'][0:n_truth_mc * n_repeat]
      - return data dict

   b) gen/fragments/normalize_data_func.py
      - def normalize_data(data): ... only (no imports)
      - Use **onp** for host-side averages / einsum
      - For each multi-component amp var present (typically *phif* with rank 3):
        regular = 1 / mean(sqrt(sum(mc_arr**2, axis=last_component)), axis=event)
        scale data/mc/truth with onp.einsum along the channel axis
      - Leave pure 1D sbc vars unchanged
      - return data

   c) gen/fragments/shard_data_distributed_func.py
      - def shard_data_distributed(data, mesh): ... only (no imports)
      - Use **np** (jax.numpy), **device_put**, **NamedSharding**, **P** from
        COMMON_UTILITIES — do not import jax / jnp yourself
      - Shard event-1d keys with NamedSharding(mesh, P("event"))
      - Shard rank-3 keys with NamedSharding(mesh, P(None, "event", None))
      - return jax_data dict of device_put arrays

5. Optional: syntax-check each .py with
   python -c "import ast; ast.parse(open(path).read()); print('OK', path)"

6. Finish (result is a **short summary only**, not a second copy of the report):
   task(
     action="finish",
     result=<1-5 lines: n_data, n_truth_mc, file counts, paths written; no full report body>,
     outputs={
       "all": "gen/fragments/data_shapes_report.txt",
       "load_data": "gen/fragments/load_data_func.py",
       "normalize_data": "gen/fragments/normalize_data_func.py",
       "shard_data_distributed": "gen/fragments/shard_data_distributed_func.py"
     }
   )

## How stage outputs are recorded (important)
- You must `write` each declared path yourself (report + 3 funcs).
- Framework **harvests** those files into output fields after finish.
- Field `all` ← content of gen/fragments/data_shapes_report.txt (the written report).
  If that file exists, its content is used for `all`; a long `result` string will
  **not** replace the report. Keep `result` as a short human summary.
- Field load_data / normalize_data / shard_data_distributed ← the corresponding .py files.

## Quality bar
- Prefer exact shapes from numpy, not guesses.
- Function code must match the actual vars/shapes found (do not hardcode foreign experiment names unless they appear in this analysis).
- No imports in fragments; reuse COMMON_UTILITIES names (`onp`, `np`, `device_put`, `NamedSharding`, `P`).
- Deduplicate vars/paths.
- Keep fragments compact; comments only for non-obvious axis choices.


## Required stage outputs (write these exact paths before task.finish)
- all → gen/fragments/data_shapes_report.txt
- load_data → gen/fragments/load_data_func.py
- normalize_data → gen/fragments/normalize_data_func.py
- shard_data_distributed → gen/fragments/shard_data_distributed_func.py

When finishing multi-file stages, call:
task(action='finish', result=<summary or primary text>, outputs={field: relative_path, ...})
Paths in outputs must match the list above. The framework will harvest file contents into the corresponding stage output fields.
```

## Response

```
Inspected six unique variables: n_data=10000 consistently and mc_truth=1200000 consistently. Applied n_truth_mc=150000 cap; all required files are present. Wrote and syntax-checked the three fragments plus the authoritative shape report.
```
