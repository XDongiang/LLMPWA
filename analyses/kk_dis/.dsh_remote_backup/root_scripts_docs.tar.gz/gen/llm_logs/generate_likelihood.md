# Stage: generate_likelihood

## Prompt

```
[system]
You are a physics-coding agent for LLMPWA partial-wave likelihood generation (non-interactive stage).

Tools:
- read: read workspace files
- write: write/overwrite workspace files
- shell: run shell commands (syntax checks + a light likelihood smoke test; do not run full fits)
- task: call task(action="finish", result=..., outputs={field: path, ...}) to submit.
  The stage is non-interactive (require_approval=false): finish is accepted immediately,
  so verify the deliverable yourself before finishing.

Hard rules:
1. Do NOT copy or depend on any full likelihood template from gen/templates/fit.py.
   You may only use: the formula provided in the task prompt (from ref.likelihood_math),
   PHYSICS helpers from run/base_functions.py, classification, free_params, and
   data/shape context below.
2. The likelihood formula specification is already provided in the task prompt
   (content of document/combined_likelihood_math.md). Do not ask the user for it.
3. Write the deliverable module to **run/likelihood_function.py**.
   It must **import and use symbols from run/base_functions.py** (do not re-define
   dplex_*, BW/flatte*, make_initial_args, save_result, or re-import jax/numpy
   independently when base_functions already provides them).
4. After writing the .py, run a **likelihood smoke test** (see task prompt) and write
   the test log to **run/likelihood_test_result.txt**.
5. No markdown fences in saved .py / .txt files.
6. If truly blocked by missing files/data, finish with an explicit failure note; do not hang.
7. After task.finish the stage ends immediately (no human approval), so self-check before finishing.


[user]
## Goal
Generate a likelihood module from the provided formula specification (below), save it under
`run/likelihood_function.py`, reuse helpers from `run/base_functions.py`, then run a
smoke test and save the test log.

## Required workflow (non-interactive)
1. Use the formula specification below (full math derivation of the combined likelihood,
   data/MC terms, amplitude classes, propagators, and fraction constraint):
   # 从 `combined_likelihood` 到 `calculate/component` 的数学过程

## 1. 总 likelihood

代码中：

```python
combined_likelihood(args, jax_data)
    = data_likelihood_kk(args, jax_data)
      + data_size * log(mc_likelihood_kk(args, jax_data))
```

数学上写为：

$$
\mathcal{L}_{\rm comb}(\theta)
=
\mathcal{L}_{\rm data}(\theta)
+
N_{\rm data}\log \mathcal{N}_{\rm MC}(\theta)
$$

其中：

- \(\theta\)：所有拟合参数；
- \(N_{\rm data}\)：真实数据事件数；
- \(\mathcal{L}_{\rm data}\)：data negative log-likelihood；
- \(\mathcal{N}_{\rm MC}\)：MC 给出的归一化积分项。

## 2. data 部分

对每个 data 事件 \(e\)，总振幅由四类振幅相干相加：

$$
\mathcal{A}_{e k}
=
\mathcal{A}^{f_0,{\rm Flatte980}}_{e k}
+
\mathcal{A}^{f_0,{\rm BW}}_{e k}
+
\mathcal{A}^{f_2,{\rm Flatte1270}}_{e k}
+
\mathcal{A}^{f_2,{\rm BW}}_{e k}
$$

其中 \(k\) 是振幅张量最后一维的分量指标。在当前 `kk` 拟合中，
`phif0_kk` 和 `phif2_kk` 的实际 shape 最后一维均为 2，因此四类振幅最终都在共同的
\(k=1,2\) 空间中相干相加。不同的是基/helicity 指标 \(i\)：`phif0_kk` 有 2 个基分量，
`phif2_kk` 有 5 个基分量。

事件强度为：

$$
I_e(\theta)
=
\sum_k
\left|
\mathcal{A}_{e k}(\theta)
\right|^2
$$

所以 data negative log-likelihood 为：

$$
\mathcal{L}_{\rm data}(\theta)
=
-
\sum_{e\in{\rm data}}
\log I_e(\theta)
+
C_{\rm penalty}(\theta)
$$

其中 penalty 来自 `data_step_function`：

$$
C_{\rm penalty}(\theta)
=
\lambda
\left(
f_{\rm total}-1.1
\right)^2
+
\sum_r
\frac{
\left(x_r-x_{r,0}\right)^2
}{
2\sigma_r^2
}
$$

代码中：

$$
\lambda = 1000
$$


## 3. MC 归一化项

MC 样本上同样构造总振幅。这里的 MC 归一化使用 `mc_*` 样本的全部事件，
不是 `truth_*` 的前 150000 个事件。`truth_*` 只用于 fraction penalty。
在当前 `load_data()` 设置 `n_repeat = 1` 时，若 `mc_truth/*.npy` 为 1200000 个事件，
则 \(\mathcal{N}_{\rm MC}\) 使用全部 1200000 个 MC 事件。

$$
\mathcal{A}^{\rm MC}_{e k}
=
\sum_\alpha
\mathcal{A}^{\alpha}_{e k}
$$

其中 \(\alpha\) 遍历四类振幅：

$$
\alpha
\in
\{
f_0{\rm -Flatte980},
f_0{\rm -BW},
f_2{\rm -Flatte1270},
f_2{\rm -BW}
\}
$$

MC 归一化为平均强度：

$$
\mathcal{N}_{\rm MC}(\theta)
=
\frac{1}{N_{\rm MC}}
\sum_{e\in{\rm MC}}
\sum_k
\left|
\mathcal{A}^{\rm MC}_{e k}(\theta)
\right|^2
$$

因此总目标函数可以写成：

$$
\boxed{
\mathcal{L}_{\rm comb}(\theta)
=
-
\sum_{e\in{\rm data}}
\log I_e(\theta)
+
C_{\rm penalty}(\theta)
+
N_{\rm data}
\log
\mathcal{N}_{\rm MC}(\theta)
}
$$

## 4. `calculate_*` 的通用振幅结构

设输入的角分布/动力学张量为：

$$
T_{i e k}
$$

其中：

- \(i\)：输入振幅基或 helicity/LS 分量指标；
- \(e\)：事件指标；
- \(k\)：末态张量分量指标。

对当前数据：

- `phif0_kk`：\(i=1,2\)，\(k=1,2\)；
- `phif2_kk`：\(i=1,\dots,5\)，\(k=1,2\)。

所以 `phif0` 与 `phif2` 的基/helicity 数不同，但被耦合求和后都得到
\(\mathcal{A}_{e k}\)，并在相同的末维 \(k=1,2\) 上相加。

复耦合常数由 `Amplitude_param_const` 和 `Amplitude_param_theta` 构造：

$$
c_{\ell i}
=
a_{\ell i}
+
i\phi_{\ell i}
$$

代码对应：

```python
const_ph = dplex_dconstruct(Amplitude_param_const, Amplitude_param_theta)
```

先做耦合加权：

$$
B_{\ell e k}
=
\sum_i
T_{i e k}
c_{\ell i}
$$

然后乘上传播子 \(P_{\ell e}\)。

若该振幅只有一个子态，可写为：

$$
\mathcal{A}_{e k}
=
B_{e k}
P_e
$$

若有多个子态 \(\ell\)，`calculate_*` 会对 \(\ell\) 相干求和：

$$
\mathcal{A}_{e k}
=
\sum_\ell
B_{\ell e k}
P_{\ell e}
$$

而 `component_*` 不对 \(\ell\) 求和，保留每个分量：

$$
\mathcal{A}^{\rm comp}_{\ell e k}
=
B_{\ell e k}
P_{\ell e}
$$

因此：

- `calculate_*` 返回总振幅，用于 likelihood；
- `component_*` 返回分振幅，用于 fraction 计算。

## 5. 传播子

### 5.1 Breit-Wigner

普通 Breit-Wigner 在代码中为 `BW`：

$$
BW(m,\Gamma;s)
=
\frac{1}{
m^2-s-im\Gamma
}
$$

其中 \(s\) 对应 `phi_kk` 或 `f_kk`。

### 5.2 `BW_flatte980`

`calculate_BW_flatte980` / `component_BW_flatte980` 使用：

$$
P_e
=
BW(m_\phi,\Gamma_\phi;s_{\phi,e})
\cdot
Flatte_{980}(m,g_{\pi\pi},r_g;s_{f,e})
$$

其中：

$$
g_{KK}
=
r_g g_{\pi\pi}
$$

$$
\rho_{KK}(s)
=
\sqrt{
\left|
1-\frac{4m_K^2}{s}
\right|
}
$$

$$
\rho_{\pi\pi}(s)
=
\sqrt{
\left|
1-\frac{4m_\pi^2}{s}
\right|
}
$$

Flatte 形式为：

$$
Flatte_{980}(s)
=
\frac{1}{
m^2-s
-
i
\left(
g_{\pi\pi}\rho_{\pi\pi}(s)
+
g_{KK}\rho_{KK}(s)
\right)
}
$$

### 5.3 `BW_BW`

`calculate_BW_BW` / `component_BW_BW` 使用：

$$
P_{\ell e}
=
BW(m_\phi,\Gamma_\phi;s_{\phi,e})
\cdot
BW(m_\ell,\Gamma_\ell;s_{f,e})
$$

其中 \(\ell\) 对应多个 \(f_0\) 或 \(f_2\) 共振态。

### 5.4 `BW_flatte1270`

`calculate_BW_flatte1270` / `component_BW_flatte1270` 使用：

$$
P_e
=
BW(m_\phi,\Gamma_\phi;s_{\phi,e})
\cdot
Flatte_{1270}(m,\Gamma;s_{f,e})
$$

代码中的 `flatte1270` 定义为：

$$
q_r^2
=
\frac{1}{4}m^2
-
0.0194792
$$

$$
b_r^2
=
q_r^2
\left(q_r^2+0.1825\right)
+
0.033306
$$

$$
g_{11270}
=
m\Gamma
\frac{
b_r^2
}{
\left(q_r^2\right)^{2.5}
}
$$

对事件 \(e\)：

$$
q_e^2
=
\frac{1}{4}s_{f,e}
-
0.0194792
$$

$$
b_e^2
=
q_e^2
\left(q_e^2+0.1825\right)
+
0.033306
$$

$$
g_1(s_{f,e})
=
g_{11270}
\frac{
\left(q_e^2\right)^{2.5}
}{
b_e^2
}
$$

于是：

$$
Flatte_{1270}(s)
=
\frac{
m\Gamma
}{
s-m^2
+
i g_1(s)
}
$$

## 6. fraction 约束

truth 样本上，代码先用 `component_*` 得到各个分量：

$$
\mathcal{A}^{\alpha}_{\ell e k}
$$

其中：

$$
\alpha
\in
\{
f_0{\rm -Flatte980},
f_0{\rm -BW},
f_2{\rm -Flatte1270},
f_2{\rm -BW}
\}
$$

总分母使用所有分量的相干和：

$$
D
=
\sum_{e,k}
\left|
\sum_\alpha
\sum_\ell
\mathcal{A}^{\alpha}_{\ell e k}
\right|^2
$$

每类 fraction 的分子为该类分量的模平方和：

$$
F_\alpha
=
\sum_{\ell,e,k}
\left|
\mathcal{A}^{\alpha}_{\ell e k}
\right|^2
$$

因此：

$$
f_\alpha
=
\frac{F_\alpha}{D}
$$

总 fraction 明确定义为四类 fraction 的和：

$$
f_{\rm total}
=
\sum_\alpha
f_\alpha
$$

即：

$$
f_{\rm total}
=
f_{f_0{\rm -Flatte980}}
+
f_{f_0{\rm -BW}}
+
f_{f_2{\rm -Flatte1270}}
+
f_{f_2{\rm -BW}}
$$

需要注意，这里的 \(D\) 是所有分量先相干求和再取模平方的总强度，而
\(F_\alpha\) 是每一类自身分量的非相干模平方和。因此各 \(f_\alpha\) 的和
不必严格等于 1，代码中用目标值 1.1 对 \(f_{\rm total}\) 加约束。

然后进入约束项：

$$
C_{\rm frac}
=
1000
\left(
f_{\rm total}-1.1
\right)^2
$$

## 7. 分布式求和含义

在该分布式脚本中，事件轴被 shard 到多个设备/进程。

数学公式中的：

$$
\sum_e
$$

和：

$$
\frac{1}{N}\sum_e
$$

在代码中分别对应 `jnp.sum` 和 `jnp.mean`。由于数组是 sharded array，JAX/XLA 会自动插入跨设备的 all-reduce，因此数学上仍然等价于对全数据集求和或求平均。


2. Implement the formula as Python in:
   **run/likelihood_function.py**
3. Run a likelihood smoke test (section "Smoke test") and write the full log to:
   **run/likelihood_test_result.txt**
4. Finish with a short summary (not the full .py body):
   task(
     action="finish",
     result=<1-10 lines: path, key functions, smoke-test status / scalar values>,
     outputs={
       "all": "run/likelihood_function.py",
       "test_result": "run/likelihood_test_result.txt"
     }
   )

## Context

### 0) Shared runtime: run/base_functions.py (MUST use; do not duplicate)
This file is already assembled by stages.assemble_help_functions. It provides
COMMON_UTILITIES, PATH setup, dplex_*, PHYSICS_FUNCTIONS, make_initial_args, save_result.

Current content (for reference; prefer `read run/base_functions.py` if needed):

```python
import json
import logging
import logging.config
import os
import toml
# must set before importing jax
os.environ["XLA_PYTHON_CLIENT_PREALLOCATE"] = "false"
import time
import numpy as onp
from functools import partial
from scipy.optimize import minimize

import jax.numpy as np
from jax import device_put, grad, jit, vmap, jvp
from jax import config
from jax.sharding import NamedSharding, PartitionSpec as P




import sys
foo_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(foo_path)
sys.path.append(foo_path)




def setup_logging():
    """Setup logging configuration"""
    with open("config/logconfig_fit.json", "r") as config_file:
        LOGGING_CONFIG = json.load(config_file)
        logging.config.dictConfig(LOGGING_CONFIG)
    return logging.getLogger("fit")




def dplex_deinsum(subscript, aa, bb):
    real = np.einsum(subscript, aa[0], bb[0]) - np.einsum(subscript, aa[1], bb[1])
    imag = np.einsum(subscript, aa[0], bb[1]) + np.einsum(subscript, aa[1], bb[0])
    return np.stack([real, imag], axis=0)

def dplex_deinsum_ord(subscript, aa, bb):
    real = np.einsum(subscript, aa, bb[0])
    imag = np.einsum(subscript, aa, bb[1])
    return np.stack([real, imag], axis=0)

def dplex_dabs(aa):
    return aa[0]**2 + aa[1]**2 # 因为是纵向叠加所以aa[0]是纵向上第一个数组

def dplex_dtomine(aa):
    return np.stack([np.real(aa), np.imag(aa)], axis=0) # 组合而成的数组 axis=0 的第一个数组为实部，第二个数组为虚部

def dplex_dconstruct(aa, bb):
    return np.stack([aa, bb], axis=0) # 纵向叠加数组 第一维为实部，第二维为虚部

def dplex_ddivide(a, bb):
    real = a * bb[0] / dplex_dabs(bb)
    imag = -a * bb[1] / dplex_dabs(bb)
    return np.stack([real, imag], axis=0)



# Physics calculation functions (resonance shape functions)
# Provided by the user for each analysis. Copy this file to your analysis
# directory as physics_functions.py and keep only the functions you need.
# ==============================================================================




def BW(m_, w_, Sbc):
    l = (Sbc.shape)[0]
    temp = dplex_dconstruct(m_*m_ - Sbc, -m_*w_*np.ones(l))
    return dplex_ddivide(1.0, temp)


def BW_relativity(m_, w_, Sbc):
    gamma = np.sqrt(m_*m_*(m_*m_+w_*w_))
    k = np.sqrt(2*np.sqrt(2)*m_*np.abs(w_)*gamma/np.pi/np.sqrt(m_*m_+gamma))
    l = (Sbc.shape)[0]
    temp = dplex_dconstruct(m_*m_ - Sbc, -m_*w_*np.ones(l))
    return dplex_ddivide(k, temp)


def flatte980(m_, g_pipi, rg, Sbc):
    g_kk = rg * g_pipi
    m_k = 0.493677
    m_pi = 0.13957061
    rho_kk = np.sqrt(np.abs(1 - 4*m_k*m_k / Sbc))
    rho_pipi = np.sqrt(np.abs(1 - 4*m_pi*m_pi / Sbc))
    tmp_A = dplex_dconstruct(m_**2 - Sbc, -1*(g_pipi*rho_pipi + g_kk*rho_kk))
    return dplex_ddivide(1.0, tmp_A)


def flatte1270(m_, w_, Sbc):
    rm = m_ * m_
    gr = m_ * w_
    q2r = 0.25 * rm - 0.0194792
    b2r = q2r * (q2r + 0.1825) + 0.033306
    g11270 = gr * b2r / np.power(q2r, 2.5)
    q2 = 0.25 * Sbc - 0.0194792
    b2 = q2 * (q2 + 0.1825) + 0.033306
    g1 = g11270 * np.power(q2, 2.5) / b2
    tmp = dplex_dconstruct(Sbc - rm, g1)
    return dplex_ddivide(gr, tmp)


def flatte500(m_, b1, b2, b3, b4, b5, Sbc):
    m2 = m_*m_
    rp = 0.139556995
    mpi2d2 = 0.009739946882
    cro1 = np.sqrt(np.abs((Sbc-(2*rp)**2)*Sbc))/Sbc
    cro2 = np.sqrt(np.abs((m2-(2*rp)**2)*m2))/m2
    pip1 = np.sqrt(np.abs(1.0 - 0.3116765584/Sbc))/(1.0+np.exp(9.8-3.5*Sbc))
    pip2 = np.sqrt(np.abs(1.0 - 0.3116765584/m2))/(1.0+np.exp(9.8-3.5*m2))
    cgam1 = m_*(b1+b2*Sbc)*(Sbc-mpi2d2)/(m2-mpi2d2)*np.exp(-(Sbc-m2)/b3)*cro1/cro2
    cgam2 = m_*b4*pip1/pip2
    tmp = dplex_dconstruct(m2-Sbc, -b5*(cgam1+cgam2))
    return dplex_ddivide(1.0, tmp)



def make_initial_args():
    _data = toml.load("run/free_params.toml")["data"]
    _data.sort(key=lambda x: x["arg_index"])

    args = [d["value"] for d in _data]
    ranges = [d.get("range", [-onp.inf, onp.inf]) for d in _data]
    errors = [d["error"] for d in _data]

    return onp.array(args), onp.array(ranges), onp.array(errors)



def save_result(args, errors, path="output/free_params_fitted.toml"):
    _data = toml.load("run/free_params.toml")["data"]
    _data.sort(key=lambda x: x["arg_index"])

    for i, d in enumerate(_data):
        d["value"] = float(args[i])
        d["error"] = float(errors[i])

    with open(path, "w") as f:
        toml.dump({"data": _data}, f)


def load_data():
    n_repeat = 1
    n_truth_mc = 150000  # intentional truth-MC cap; this is not n_data
    data = {}

    data['data_phi_kk'] = onp.tile(onp.load('data/real_data/phi_kk.npy'), n_repeat)
    data['mc_phi_kk'] = onp.tile(onp.load('data/mc_truth/phi_kk.npy'), n_repeat)
    data['truth_phi_kk'] = data['mc_phi_kk'][0:n_truth_mc * n_repeat]

    data['data_f_kk'] = onp.tile(onp.load('data/real_data/f_kk.npy'), n_repeat)
    data['mc_f_kk'] = onp.tile(onp.load('data/mc_truth/f_kk.npy'), n_repeat)
    data['truth_f_kk'] = data['mc_f_kk'][0:n_truth_mc * n_repeat]

    data['data_phif0_kk'] = onp.tile(onp.load('data/real_data/phif0_kk.npy'), (1, n_repeat, 1))
    data['mc_phif0_kk'] = onp.tile(onp.load('data/mc_truth/phif0_kk.npy'), (1, n_repeat, 1))
    data['truth_phif0_kk'] = data['mc_phif0_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_phif2_kk'] = onp.tile(onp.load('data/real_data/phif2_kk.npy'), (1, n_repeat, 1))
    data['mc_phif2_kk'] = onp.tile(onp.load('data/mc_truth/phif2_kk.npy'), (1, n_repeat, 1))
    data['truth_phif2_kk'] = data['mc_phif2_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_b123_kk'] = onp.tile(onp.load('data/real_data/b123_kk.npy'), n_repeat)
    data['mc_b123_kk'] = onp.tile(onp.load('data/mc_truth/b123_kk.npy'), n_repeat)
    data['truth_b123_kk'] = data['mc_b123_kk'][0:n_truth_mc * n_repeat]

    data['data_b124_kk'] = onp.tile(onp.load('data/real_data/b124_kk.npy'), n_repeat)
    data['mc_b124_kk'] = onp.tile(onp.load('data/mc_truth/b124_kk.npy'), n_repeat)
    data['truth_b124_kk'] = data['mc_b124_kk'][0:n_truth_mc * n_repeat]

    return data


def normalize_data(data):
    for var in ('phif0_kk', 'phif2_kk'):
        mc_arr = data['mc_' + var]
        regular = 1.0 / onp.mean(
            onp.sqrt(onp.sum(mc_arr ** 2, axis=-1)), axis=1
        )
        for prefix in ('data_', 'mc_', 'truth_'):
            key = prefix + var
            data[key] = onp.einsum('c,cek->cek', regular, data[key])
    return data


def shard_data_distributed(data, mesh):
    jax_data = {}
    for key, value in data.items():
        array = np.asarray(value)
        if array.ndim == 1:
            spec = P('event')
        elif array.ndim == 3:
            spec = P(None, 'event', None)
        else:
            raise ValueError('Unsupported data rank for ' + key + ': ' + str(array.ndim))
        jax_data[key] = device_put(array, NamedSharding(mesh, spec))
    return jax_data



```

Import policy for `run/likelihood_function.py`:
- Import symbols **from base_functions** (module lives next to this file under `run/`):
  e.g.
  ```python
  from base_functions import (
      np, onp, device_put, grad, jit, jvp, vmap,
      dplex_dabs, dplex_deinsum, dplex_dconstruct, dplex_ddivide, ...
      BW, flatte980, flatte1270, ...
      make_initial_args,
  )
  ```
  Adjust the import list to what you actually use. Prefer `from base_functions import ...`
  over re-declaring `import jax.numpy as np` / `import numpy as onp` when already available.
- Do **not** redefine dplex_* / BW / flatte* / make_initial_args / save_result.
- Data loaders may come from inspect_data_shapes fragments if present:
  - def load_data():
    n_repeat = 1
    n_truth_mc = 150000  # intentional truth-MC cap; this is not n_data
    data = {}

    data['data_phi_kk'] = onp.tile(onp.load('data/real_data/phi_kk.npy'), n_repeat)
    data['mc_phi_kk'] = onp.tile(onp.load('data/mc_truth/phi_kk.npy'), n_repeat)
    data['truth_phi_kk'] = data['mc_phi_kk'][0:n_truth_mc * n_repeat]

    data['data_f_kk'] = onp.tile(onp.load('data/real_data/f_kk.npy'), n_repeat)
    data['mc_f_kk'] = onp.tile(onp.load('data/mc_truth/f_kk.npy'), n_repeat)
    data['truth_f_kk'] = data['mc_f_kk'][0:n_truth_mc * n_repeat]

    data['data_phif0_kk'] = onp.tile(onp.load('data/real_data/phif0_kk.npy'), (1, n_repeat, 1))
    data['mc_phif0_kk'] = onp.tile(onp.load('data/mc_truth/phif0_kk.npy'), (1, n_repeat, 1))
    data['truth_phif0_kk'] = data['mc_phif0_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_phif2_kk'] = onp.tile(onp.load('data/real_data/phif2_kk.npy'), (1, n_repeat, 1))
    data['mc_phif2_kk'] = onp.tile(onp.load('data/mc_truth/phif2_kk.npy'), (1, n_repeat, 1))
    data['truth_phif2_kk'] = data['mc_phif2_kk'][:, 0:n_truth_mc * n_repeat, ...]

    data['data_b123_kk'] = onp.tile(onp.load('data/real_data/b123_kk.npy'), n_repeat)
    data['mc_b123_kk'] = onp.tile(onp.load('data/mc_truth/b123_kk.npy'), n_repeat)
    data['truth_b123_kk'] = data['mc_b123_kk'][0:n_truth_mc * n_repeat]

    data['data_b124_kk'] = onp.tile(onp.load('data/real_data/b124_kk.npy'), n_repeat)
    data['mc_b124_kk'] = onp.tile(onp.load('data/mc_truth/b124_kk.npy'), n_repeat)
    data['truth_b124_kk'] = data['mc_b124_kk'][0:n_truth_mc * n_repeat]

    return data
 may be inlined by reading
    gen/fragments/load_data_func.py, or import if you place a thin wrapper.
  Preferred for the smoke test: `exec`/import the load_data / normalize_data /
  shard_data_distributed functions from gen/fragments/*_func.py **only in the test
  harness or __main__**, not re-implement physics in likelihood.

### 1) PHYSICS_FUNCTIONS already in base_functions (also shown for formula design)
```python
def dplex_deinsum(subscript, aa, bb):
    real = np.einsum(subscript, aa[0], bb[0]) - np.einsum(subscript, aa[1], bb[1])
    imag = np.einsum(subscript, aa[0], bb[1]) + np.einsum(subscript, aa[1], bb[0])
    return np.stack([real, imag], axis=0)

def dplex_deinsum_ord(subscript, aa, bb):
    real = np.einsum(subscript, aa, bb[0])
    imag = np.einsum(subscript, aa, bb[1])
    return np.stack([real, imag], axis=0)

def dplex_dabs(aa):
    return aa[0]**2 + aa[1]**2 # 因为是纵向叠加所以aa[0]是纵向上第一个数组

def dplex_dtomine(aa):
    return np.stack([np.real(aa), np.imag(aa)], axis=0) # 组合而成的数组 axis=0 的第一个数组为实部，第二个数组为虚部

def dplex_dconstruct(aa, bb):
    return np.stack([aa, bb], axis=0) # 纵向叠加数组 第一维为实部，第二维为虚部

def dplex_ddivide(a, bb):
    real = a * bb[0] / dplex_dabs(bb)
    imag = -a * bb[1] / dplex_dabs(bb)
    return np.stack([real, imag], axis=0)


# Physics calculation functions (resonance shape functions)
# Provided by the user for each analysis. Copy this file to your analysis
# directory as physics_functions.py and keep only the functions you need.
# ==============================================================================




def BW(m_, w_, Sbc):
    l = (Sbc.shape)[0]
    temp = dplex_dconstruct(m_*m_ - Sbc, -m_*w_*np.ones(l))
    return dplex_ddivide(1.0, temp)


def BW_relativity(m_, w_, Sbc):
    gamma = np.sqrt(m_*m_*(m_*m_+w_*w_))
    k = np.sqrt(2*np.sqrt(2)*m_*np.abs(w_)*gamma/np.pi/np.sqrt(m_*m_+gamma))
    l = (Sbc.shape)[0]
    temp = dplex_dconstruct(m_*m_ - Sbc, -m_*w_*np.ones(l))
    return dplex_ddivide(k, temp)


def flatte980(m_, g_pipi, rg, Sbc):
    g_kk = rg * g_pipi
    m_k = 0.493677
    m_pi = 0.13957061
    rho_kk = np.sqrt(np.abs(1 - 4*m_k*m_k / Sbc))
    rho_pipi = np.sqrt(np.abs(1 - 4*m_pi*m_pi / Sbc))
    tmp_A = dplex_dconstruct(m_**2 - Sbc, -1*(g_pipi*rho_pipi + g_kk*rho_kk))
    return dplex_ddivide(1.0, tmp_A)


def flatte1270(m_, w_, Sbc):
    rm = m_ * m_
    gr = m_ * w_
    q2r = 0.25 * rm - 0.0194792
    b2r = q2r * (q2r + 0.1825) + 0.033306
    g11270 = gr * b2r / np.power(q2r, 2.5)
    q2 = 0.25 * Sbc - 0.0194792
    b2 = q2 * (q2 + 0.1825) + 0.033306
    g1 = g11270 * np.power(q2, 2.5) / b2
    tmp = dplex_dconstruct(Sbc - rm, g1)
    return dplex_ddivide(gr, tmp)


def flatte500(m_, b1, b2, b3, b4, b5, Sbc):
    m2 = m_*m_
    rp = 0.139556995
    mpi2d2 = 0.009739946882
    cro1 = np.sqrt(np.abs((Sbc-(2*rp)**2)*Sbc))/Sbc
    cro2 = np.sqrt(np.abs((m2-(2*rp)**2)*m2))/m2
    pip1 = np.sqrt(np.abs(1.0 - 0.3116765584/Sbc))/(1.0+np.exp(9.8-3.5*Sbc))
    pip2 = np.sqrt(np.abs(1.0 - 0.3116765584/m2))/(1.0+np.exp(9.8-3.5*m2))
    cgam1 = m_*(b1+b2*Sbc)*(Sbc-mpi2d2)/(m2-mpi2d2)*np.exp(-(Sbc-m2)/b3)*cro1/cro2
    cgam2 = m_*b4*pip1/pip2
    tmp = dplex_dconstruct(m2-Sbc, -b5*(cgam1+cgam2))
    return dplex_ddivide(1.0, tmp)

```

### 2) Resonance classification (from stages.classification)
```json
{
  "propagator_classification": {
    "BW_flatte980": [
      "phif0_980"
    ],
    "BW_BW": [
      "phif0_1710",
      "phif2_1270",
      "phif2_1525",
      "phif2_2150",
      "phif2_2340",
      "phif0_2470"
    ]
  },
  "amplitude_classification": {
    "phif0_kk_BW_flatte980": [
      "phif0_980"
    ],
    "phif0_kk_BW_BW": [
      "phif0_1710",
      "phif0_2470"
    ],
    "phif2_kk_BW_BW": [
      "phif2_1270",
      "phif2_1525",
      "phif2_2150",
      "phif2_2340"
    ]
  },
  "parameter_lists": {
    "phif0_kk_BW_flatte980": {
      "A_mass": [
        1.02
      ],
      "A_width": [
        0.004
      ],
      "B_mass": [
        0
      ],
      "B_g_kk": [
        1
      ],
      "B_rg": [
        2
      ],
      "const": [
        [
          0.1,
          3
        ]
      ],
      "theta": [
        [
          0.1,
          4
        ]
      ]
    },
    "phif0_kk_BW_BW": {
      "A_mass": [
        1.02,
        1.02
      ],
      "A_width": [
        0.004,
        0.004
      ],
      "B_mass": [
        5,
        59
      ],
      "B_width": [
        6,
        60
      ],
      "const": [
        [
          7,
          8
        ],
        [
          61,
          62
        ]
      ],
      "theta": [
        [
          9,
          10
        ],
        [
          63,
          64
        ]
      ]
    },
    "phif2_kk_BW_BW": {
      "A_mass": [
        1.02,
        1.02,
        1.02,
        1.02
      ],
      "A_width": [
        0.004,
        0.004,
        0.004,
        0.004
      ],
      "B_mass": [
        11,
        23,
        35,
        47
      ],
      "B_width": [
        12,
        24,
        36,
        48
      ],
      "const": [
        [
          13,
          14,
          15,
          16,
          17
        ],
        [
          25,
          26,
          27,
          28,
          29
        ],
        [
          37,
          38,
          39,
          40,
          41
        ],
        [
          49,
          50,
          51,
          52,
          53
        ]
      ],
      "theta": [
        [
          18,
          19,
          20,
          21,
          22
        ],
        [
          30,
          31,
          32,
          33,
          34
        ],
        [
          42,
          43,
          44,
          45,
          46
        ],
        [
          54,
          55,
          56,
          57,
          58
        ]
      ]
    }
  },
  "fixed_parameter": {
    "phif0_kk_BW_flatte980": [
      "A_mass",
      "A_width",
      "const1",
      "theta1"
    ],
    "phif0_kk_BW_BW": [
      "A_mass",
      "A_width"
    ],
    "phif2_kk_BW_BW": [
      "A_mass",
      "A_width"
    ]
  }
}
```

Useful fields:
- propagator_classification / amplitude_classification
- parameter_lists: free params as {"arg_index": n}
- fixed_parameter: stay constant

### 3) free parameters (args vector)
Source: stages.config_strip.free_params → run/free_params.toml
```
{
  "data": [
    {
      "path": "resonances.phif0_980.propagators.B_propagator.mass",
      "value": 0.9794812115574156,
      "range": [
        0.98,
        10.0
      ],
      "error": 0.0029114167854559173,
      "arg_index": 0
    },
    {
      "path": "resonances.phif0_980.propagators.B_propagator.g_kk",
      "value": 0.10678616326827592,
      "error": 0.010260657247901088,
      "arg_index": 1
    },
    {
      "path": "resonances.phif0_980.propagators.B_propagator.rg",
      "value": 8.570187550432664,
      "error": 1.348489540060868,
      "arg_index": 2
    },
    {
      "path": "resonances.phif0_980.Amplitude.const2",
      "value": 0.1065182971468388,
      "error": 0.003833456119689838,
      "arg_index": 3
    },
    {
      "path": "resonances.phif0_980.Amplitude.theta2",
      "value": 0.03807025376236671,
      "error": 0.0032382807585900437,
      "arg_index": 4
    },
    {
      "path": "resonances.phif0_1710.propagators.B_propagator.mass",
      "value": 1.6761965590304995,
      "range": [
        1.704,
        1.0
      ],
      "error": 0.008608254171218993,
      "arg_index": 5
    },
    {
      "path": "resonances.phif0_1710.propagators.B_propagator.width",
      "value": 0.16270071108440043,
      "range": [
        0.123,
        1.0
      ],
      "error": 0.007928828044131218,
      "arg_index": 6
    },
    {
      "path": "resonances.phif0_1710.Amplitude.const1",
      "value": 0.02201375198386279,
      "error": 0.0028493281809777366,
      "arg_index": 7
    },
    {
      "path": "resonances.phif0_1710.Amplitude.const2",
      "value": 0.007433204877151768,
      "error": 0.0027873338673183225,
      "arg_index": 8
    },
    {
      "path": "resonances.phif0_1710.Amplitude.theta1",
      "value": 0.008302300118288414,
      "error": 0.003420832265462995,
      "arg_index": 9
    },
    {
      "path": "resonances.phif0_1710.Amplitude.theta2",
      "value": -0.018544178045626723,
      "error": 0.002285070372617045,
      "arg_index": 10
    },
    {
      "path": "resonances.phif2_1270.propagators.B_propagator.mass",
      "value": 1.2896149318644679,
      "range": [
        1.2755,
        1.0
      ],
      "error": 0.008900150561499074,
      "arg_index": 11
    },
    {
      "path": "resonances.phif2_1270.propagators.B_propagator.width",
      "value": 0.1959796900380022,
      "range": [
        0.1867,
        1.0
      ],
      "error": 0.009003877508753227,
      "arg_index": 12
    },
    {
      "path": "resonances.phif2_1270.Amplitude.const1",
      "value": -0.013533706721054747,
      "error": 0.013059446776572923,
      "arg_index": 13
    },
    {
      "path": "resonances.phif2_1270.Amplitude.const2",
      "value": -0.01650921272412254,
      "error": 0.011103610207449996,
      "arg_index": 14
    },
    {
      "path": "resonances.phif2_1270.Amplitude.const3",
      "value": 0.015339403283337268,
      "error": 0.007598401439603328,
      "arg_index": 15
    },
    {
      "path": "resonances.phif2_1270.Amplitude.const4",
      "value": 0.029798824827026338,
      "error": 0.013596613875924366,
      "arg_index": 16
    },
    {
      "path": "resonances.phif2_1270.Amplitude.const5",
      "value": 0.020982478502465995,
      "error": 0.011084121094273973,
      "arg_index": 17
    },
    {
      "path": "resonances.phif2_1270.Amplitude.theta1",
      "value": 0.05458389002821978,
      "error": 0.010607053111143525,
      "arg_index": 18
    },
    {
      "path": "resonances.phif2_1270.Amplitude.theta2",
      "value": 0.016032334798079934,
      "error": 0.009620235767829567,
      "arg_index": 19
    },
    {
      "path": "resonances.phif2_1270.Amplitude.theta3",
      "value": 0.017179622009723918,
      "error": 0.008259678006502619,
      "arg_index": 20
    },
    {
      "path": "resonances.phif2_1270.Amplitude.theta4",
      "value": -0.050143087437086675,
      "error": 0.010731665771685451,
      "arg_index": 21
    },
    {
      "path": "resonances.phif2_1270.Amplitude.theta5",
      "value": -0.008718872479379924,
      "error": 0.009363006763018657,
      "arg_index": 22
    },
    {
      "path": "resonances.phif2_1525.propagators.B_propagator.mass",
      "value": 1.5222602842746435,
      "range": [
        1.517,
        1.0
      ],
      "error": 0.0021852818767245097,
      "arg_index": 23
    },
    {
      "path": "resonances.phif2_1525.propagators.B_propagator.width",
      "value": 0.08576525399315078,
      "range": [
        0.086,
        1.0
      ],
      "error": 0.004480554483528854,
      "arg_index": 24
    },
    {
      "path": "resonances.phif2_1525.Amplitude.const1",
      "value": -0.005345214125595505,
      "error": 0.002361030920067052,
      "arg_index": 25
    },
    {
      "path": "resonances.phif2_1525.Amplitude.const2",
      "value": 0.0031770703345810553,
      "error": 0.0022601284491659272,
      "arg_index": 26
    },
    {
      "path": "resonances.phif2_1525.Amplitude.const3",
      "value": -0.0036743677603351056,
      "error": 0.0018391542634132708,
      "arg_index": 27
    },
    {
      "path": "resonances.phif2_1525.Amplitude.const4",
      "value": 0.004813366936315499,
      "error": 0.0034476100080681558,
      "arg_index": 28
    },
    {
      "path": "resonances.phif2_1525.Amplitude.const5",
      "value": 0.010000673114238258,
      "error": 0.0024458295985315373,
      "arg_index": 29
    },
    {
      "path": "resonances.phif2_1525.Amplitude.theta1",
      "value": -0.010529063356530807,
      "error": 0.002019182721147269,
      "arg_index": 30
    },
    {
      "path": "resonances.phif2_1525.Amplitude.theta2",
      "value": 0.003910028530572422,
      "error": 0.0014883832205133188,
      "arg_index": 31
    },
    {
      "path": "resonances.phif2_1525.Amplitude.theta3",
      "value": 0.0031787953173277725,
      "error": 0.0009832831099109687,
      "arg_index": 32
    },
    {
      "path": "resonances.phif2_1525.Amplitude.theta4",
      "value": 0.0333658928584713,
      "error": 0.0037659511330376417,
      "arg_index": 33
    },
    {
      "path": "resonances.phif2_1525.Amplitude.theta5",
      "value": -0.006053516058970728,
      "error": 0.0016345295470368193,
      "arg_index": 34
    },
    {
      "path": "resonances.phif2_2150.propagators.B_propagator.mass",
      "value": 2.1619576785269476,
      "range": [
        2.157,
        1.0
      ],
      "error": 0.009091748268572158,
      "arg_index": 35
    },
    {
      "path": "resonances.phif2_2150.propagators.B_propagator.width",
      "value": 0.15906049251159413,
      "range": [
        0.152,
        1.0
      ],
      "error": 0.009061189535661485,
      "arg_index": 36
    },
    {
      "path": "resonances.phif2_2150.Amplitude.const1",
      "value": 0.004643720949518616,
      "error": 0.004293173395970161,
      "arg_index": 37
    },
    {
      "path": "resonances.phif2_2150.Amplitude.const2",
      "value": -0.0009682564746806725,
      "error": 0.004579214352357212,
      "arg_index": 38
    },
    {
      "path": "resonances.phif2_2150.Amplitude.const3",
      "value": -0.0029804674908844213,
      "error": 0.0025923332971131054,
      "arg_index": 39
    },
    {
      "path": "resonances.phif2_2150.Amplitude.const4",
      "value": 0.008315390493289363,
      "error": 0.004795045874173534,
      "arg_index": 40
    },
    {
      "path": "resonances.phif2_2150.Amplitude.const5",
      "value": 0.0005819695034846763,
      "error": 0.004151013688821708,
      "arg_index": 41
    },
    {
      "path": "resonances.phif2_2150.Amplitude.theta1",
      "value": 0.00545992748088964,
      "error": 0.003178818200828604,
      "arg_index": 42
    },
    {
      "path": "resonances.phif2_2150.Amplitude.theta2",
      "value": -0.012498776031677225,
      "error": 0.004094191659114589,
      "arg_index": 43
    },
    {
      "path": "resonances.phif2_2150.Amplitude.theta3",
      "value": 0.002196563552197887,
      "error": 0.0024912191401879813,
      "arg_index": 44
    },
    {
      "path": "resonances.phif2_2150.Amplitude.theta4",
      "value": -0.016814307435916394,
      "error": 0.0032647649405574786,
      "arg_index": 45
    },
    {
      "path": "resonances.phif2_2150.Amplitude.theta5",
      "value": -0.007232946300343621,
      "error": 0.003910253340981285,
      "arg_index": 46
    },
    {
      "path": "resonances.phif2_2340.propagators.B_propagator.mass",
      "value": 2.547889297662712,
      "range": [
        2.345,
        0.01
      ],
      "error": 0.025714265576588485,
      "arg_index": 47
    },
    {
      "path": "resonances.phif2_2340.propagators.B_propagator.width",
      "value": 0.324001266488012,
      "range": [
        0.322,
        1.0
      ],
      "error": 0.008869958469754202,
      "arg_index": 48
    },
    {
      "path": "resonances.phif2_2340.Amplitude.const1",
      "value": -0.15266341362240637,
      "error": 0.0226276447864268,
      "arg_index": 49
    },
    {
      "path": "resonances.phif2_2340.Amplitude.const2",
      "value": -0.05030214288962155,
      "error": 0.01462254664631181,
      "arg_index": 50
    },
    {
      "path": "resonances.phif2_2340.Amplitude.const3",
      "value": -0.01856511044577769,
      "error": 0.01602693686543622,
      "arg_index": 51
    },
    {
      "path": "resonances.phif2_2340.Amplitude.const4",
      "value": 0.0908719088071242,
      "error": 0.015326282883084562,
      "arg_index": 52
    },
    {
      "path": "resonances.phif2_2340.Amplitude.const5",
      "value": 0.029544599934778714,
      "error": 0.014428141030373473,
      "arg_index": 53
    },
    {
      "path": "resonances.phif2_2340.Amplitude.theta1",
      "value": 0.06277085590848677,
      "error": 0.01543028339321429,
      "arg_index": 54
    },
    {
      "path": "resonances.phif2_2340.Amplitude.theta2",
      "value": -0.0031366601030189344,
      "error": 0.01485537124391433,
      "arg_index": 55
    },
    {
      "path": "resonances.phif2_2340.Amplitude.theta3",
      "value": 0.13756083806604205,
      "error": 0.015675234074991284,
      "arg_index": 56
    },
    {
      "path": "resonances.phif2_2340.Amplitude.theta4",
      "value": -0.0033564526519642953,
      "error": 0.01289703559343365,
      "arg_index": 57
    },
    {
      "path": "resonances.phif2_2340.Amplitude.theta5",
      "value": 0.06849361819185686,
      "error": 0.016369611794000778,
      "arg_index": 58
    },
    {
      "path": "resonances.phif0_2470.propagators.B_propagator.mass",
      "value": 2.57497529295397,
      "range": [
        2.47,
        0.007
      ],
      "error": 0.00489289053639705,
      "arg_index": 59
    },
    {
      "path": "resonances.phif0_2470.propagators.B_propagator.width",
      "value": 0.15761784400243628,
      "range": [
        0.075,
        0.011
      ],
      "error": 0.008657054415984383,
      "arg_index": 60
    },
    {
      "path": "resonances.phif0_2470.Amplitude.const1",
      "value": -0.345074426966773,
      "error": 0.01955694586578195,
      "arg_index": 61
    },
    {
      "path": "resonances.phif0_2470.Amplitude.const2",
      "value": -0.15428119408751656,
      "error": 0.014870979855746012,
      "arg_index": 62
    },
    {
      "path": "resonances.phif0_2470.Amplitude.theta1",
      "value": 0.2290031973516395,
      "error": 0.010330891827371173,
      "arg_index": 63
    },
    {
      "path": "resonances.phif0_2470.Amplitude.theta2",
      "value": -0.13412740539296167,
      "error": 0.01384041134802183,
      "arg_index": 64
    }
  ]
}
```
1-D args array; index i ↔ arg_index=i. Use make_initial_args() from base_functions
to obtain a starting vector for the smoke test.

### 4) data / shapes
sbc: phi_kk

f_kk
amp: phif0_kk

phif2_kk
sbc-amp: {
  "phif0_kk": [
    "{'sbc': 'phi_kk', 'propagator_type': 'BW'}",
    "{'sbc': 'f_kk', 'propagator_type': 'flatte980'}",
    "{'sbc': 'f_kk', 'propagator_type': 'BW'}"
  ],
  "phif2_kk": [
    "{'sbc': 'phi_kk', 'propagator_type': 'BW'}",
    "{'sbc': 'f_kk', 'propagator_type': 'flatte1270'}",
    "{'sbc': 'f_kk', 'propagator_type': 'BW'}"
  ]
}

Shape report:
```
Data preprocessing shape report
===============================

Unique variables selected from stripped_config.toml and supplied lists:
- sbc: phi_kk, f_kk
- amplitude: phif0_kk, phif2_kk
- draw.extra_sbc: b123_kk, b124_kk

Required real_data and mc_truth files:
path                                      shape                 dtype    status
--------------------------------------------------------------------------------
data/real_data/phi_kk.npy                (10000,)              float64   present
data/mc_truth/phi_kk.npy                 (1200000,)            float64   present
data/real_data/f_kk.npy                  (10000,)              float64   present
data/mc_truth/f_kk.npy                   (1200000,)            float64   present
data/real_data/phif0_kk.npy              (2, 10000, 2)          float64   present
data/mc_truth/phif0_kk.npy               (2, 1200000, 2)        float64   present
data/real_data/phif2_kk.npy              (5, 10000, 2)          float64   present
data/mc_truth/phif2_kk.npy               (5, 1200000, 2)        float64   present
data/real_data/b123_kk.npy               (10000,)              float64   present
data/mc_truth/b123_kk.npy                (1200000,)            float64   present
data/real_data/b124_kk.npy               (10000,)              float64   present
data/mc_truth/b124_kk.npy                (1200000,)            float64   present

Related files (not used by load_data):
data/draw_data/phi_kk.npy                (500000,)              float64   present
data/draw_mc/phi_kk.npy                  (500000,)              float64   present
data/draw_data/f_kk.npy                  (500000,)              float64   present
data/draw_mc/f_kk.npy                    (500000,)              float64   present
data/draw_data/phif0_kk.npy              (2, 500000, 2)        float64   present
data/draw_mc/phif0_kk.npy                (2, 500000, 2)          float64   present
data/draw_data/phif2_kk.npy              (5, 500000, 2)        float64   present
data/draw_mc/phif2_kk.npy                (5, 500000, 2)          float64   present
data/draw_data/b123_kk.npy               (500000,)              float64   present
data/draw_mc/b123_kk.npy                 (1000000,)            float64   present
data/draw_data/b124_kk.npy               (500000,)              float64   present
data/draw_mc/b124_kk.npy                 (1000000,)            float64   present
data/weight/weight_kk.npy                present (shape not variable-specific)
data/weight/weight_pipi.npy              present (shape not variable-specific)

Sizes and consistency:
- n_data = 10000 for every listed real_data variable; event counts are consistent.
- mc_truth event count = 1200000 for every listed variable; counts are consistent.
- n_repeat = 1.
- chosen n_truth_mc = 150000 (intentional truth-MC compute/memory cap, not n_data).
- truth arrays therefore use the first 150000 events along the event axis.

Summary: six required variables are present in both real_data and mc_truth. The two amplitude arrays are rank 3 with channel/event/component layouts (2, N, 2) and (5, N, 2); the four sbc/extra_sbc arrays are 1D. No required files are missing.

```

Preprocessing fragments (load / normalize / shard) are under gen/fragments/*_func.py
from stages.inspect_data_shapes. Use them for the smoke test data path; do not rewrite
unless the formula needs different packing.

### 5) Interface contract for run/likelihood_function.py
Define at least:
- extract_parameters(args) -> dict
- data_likelihood_kk(args, data_or_jax_data) -> scalar
- mc_likelihood_kk(args, data_or_jax_data) -> scalar
- combined_likelihood(args, data_or_jax_data) -> scalar
  default if user does not override:
  combined = data_likelihood + data_size * np.log(mc_likelihood)
- optional: hvp_combined_likelihood / factory make_distributed_likelihood(data_size)

Helpers (calculate_* / component_*) as needed, built from base_functions physics + dplex_*.

Also provide a runnable smoke entry so the agent (and humans) can re-test, e.g.:
```python
if __name__ == "__main__":
    # load data via inspect fragments or a minimal path, call combined_likelihood once, print scalars
    ...
```

## Smoke test (required before finish)
Write and execute a light check (shell). Goals: prove the module imports and returns finite scalars.

Suggested procedure (adapt to available files / devices):
1. Ensure `run/likelihood_function.py` exists and `ast.parse` succeeds.
2. From analysis workdir, run something equivalent to:
   ```bash
   python - <<'PY'
   import sys, traceback
   sys.path.insert(0, "run")
   from base_functions import make_initial_args, np, onp
   import likelihood_function as lf
   # load data: prefer load_data/normalize from gen/fragments if present
   ...
   args, *_ = make_initial_args()  # unpack whatever make_initial_args returns
   # compute data_size from real data length
   val = lf.combined_likelihood(args, data)  # or distributed variant
   print("combined_likelihood =", float(val))
   PY
   ```
3. Capture stdout/stderr + final status into **run/likelihood_test_result.txt**, including:
   - timestamp / command
   - import OK / syntax OK
   - n_args, data_size (if known)
   - printed likelihood scalar(s) (data / mc / combined if available)
   - PASS or FAIL + exception traceback on failure
4. If the test FAILs, fix the .py and re-run until PASS (formula/data are already provided).
5. Prefer CPU / small subsets if full mc is too heavy; still use real free_params via make_initial_args.
   Do **not** launch a full minimizer fit in this stage.

## Implementation guidance
- Translate user LaTeX into executable code using **np** (jax.numpy from base_functions).
- Respect classification groups for vectorization when possible.
- Use free_params / parameter_lists for args vs constants.
- Use shape report for broadcasting / einsum axes.
- Keep code compact; no #=== section banners.
- task.finish `result` = short summary only; framework harvests the two files for
  output.all and output.test_result.

## Deliverables checklist
- [ ] run/likelihood_function.py  (imports from base_functions; implements likelihood API)
- [ ] run/likelihood_test_result.txt  (smoke test log with PASS and numeric likelihood)
- [ ] task.finish with outputs map pointing at both paths


## Required stage outputs (write these exact paths before task.finish)
- all → run/likelihood_function.py
- test_result → run/likelihood_test_result.txt

When finishing multi-file stages, call:
task(action='finish', result=<summary or primary text>, outputs={field: relative_path, ...})
Paths in outputs must match the list above. The framework will harvest file contents into the corresponding stage output fields.
```

## Response

```
Created run/likelihood_function.py with parameter extraction, four coherent amplitude categories, truth-fraction and Gaussian penalties, data/MC likelihoods, combined likelihood, distributed factory, and HVP.
Smoke test PASS on CPU subsets: data=-715.3539428710938, MC=6145.71142578125, combined=401.25531005859375.
```
