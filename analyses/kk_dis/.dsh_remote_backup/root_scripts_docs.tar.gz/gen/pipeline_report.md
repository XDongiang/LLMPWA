# LLMPWA 流水线报告 — `/home/iso/openclaw/deepseek-harness/LLMPWA/analyses/kk_dis`

- 配置文件：`llm_config_fit.toml`
- 生成时间：`2026-09-08T17:35:58+0800`
- stage 数：`8`；参数数：`81`

## Stage DAG

```mermaid
graph TD
    config_strip["config_strip<br/>(py)"]
    inspect_data_shapes["inspect_data_shapes<br/>(agent)"]
    make_initial_args["make_initial_args<br/>(py)"]
    save_results["save_results<br/>(py)"]
    assemble_help_functions["assemble_help_functions<br/>(py)"]
    classification["classification<br/>(llm)"]
    generate_likelihood["generate_likelihood<br/>(agent)"]
    generate_fit_script["generate_fit_script<br/>(agent)"]
    assemble_help_functions --> generate_fit_script
    assemble_help_functions --> generate_likelihood
    classification --> generate_likelihood
    config_strip --> classification
    config_strip --> generate_likelihood
    config_strip --> inspect_data_shapes
    generate_likelihood --> generate_fit_script
    inspect_data_shapes --> assemble_help_functions
    inspect_data_shapes --> generate_likelihood
    make_initial_args --> assemble_help_functions
    save_results --> assemble_help_functions
```

## Stage 状态

| # | stage | kind | 状态 | 依赖 | foreach |
|---|-------|------|------|------|---------|
| 0 | `config_strip` | python | **missing** | — | — |
| 1 | `inspect_data_shapes` | agent | **missing** | config_strip | — |
| 2 | `make_initial_args` | python | **missing** | — | — |
| 3 | `save_results` | python | **missing** | — | — |
| 4 | `assemble_help_functions` | python | **missing** | make_initial_args, save_results, inspect_data_shapes | — |
| 5 | `classification` | llm | **missing** | config_strip | — |
| 6 | `generate_likelihood` | agent | **missing** | assemble_help_functions, inspect_data_shapes, classification, config_strip | — |
| 7 | `generate_fit_script` | agent | **missing** | assemble_help_functions, generate_likelihood | — |

## 产物代码文件

### templates
- `gen/templates/draw.py`
- `gen/templates/fit.py`
- `gen/templates/physics_functions.py`
- `gen/templates/plot.py`
- `gen/templates/shared.py`

### prompts
- `gen/prompts/classification_prompt.txt`
- `gen/prompts/combined_likelihood_math.md`
- `gen/prompts/data_load_prompt.txt`
- `gen/prompts/extract_parameters_prompt.txt`
- `gen/prompts/generate_fit_script_system.txt`
- `gen/prompts/generate_fit_script_task.txt`
- `gen/prompts/generate_likelihood_system.txt`
- `gen/prompts/generate_likelihood_task.txt`
- `gen/prompts/inspect_data_shapes_system.txt`
- `gen/prompts/inspect_data_shapes_task.txt`
- `gen/prompts/likelihood_function_prompt.txt`
- `gen/prompts/main_section_prompt.txt`
- `gen/prompts/resonance_calculation_prompt.txt`
- `gen/prompts/run_load_data_prompt.txt`

### run_scripts
- `run/base_functions.py`
- `run/fit_script.py`
- `run/free_params.toml`
- `run/likelihood_function.py`

## 参数 / 共振态配置

| 共振态 | 参数路径 | 值 | fixed | range | error |
|--------|----------|----|-------|-------|-------|
| resonance:resonances | `phif0_980.propagators.A_propagator.mass` | 1.02 | True | — | — |
| resonance:resonances | `phif0_980.propagators.A_propagator.width` | 0.004 | True | — | — |
| resonance:resonances | `phif0_980.propagators.B_propagator.mass` | 0.9794812115574156 | False | [0.98, 10.0] | 0.0029114167854559173 |
| resonance:resonances | `phif0_980.propagators.B_propagator.g_kk` | 0.10678616326827592 | False | — | 0.010260657247901088 |
| resonance:resonances | `phif0_980.propagators.B_propagator.rg` | 8.570187550432664 | False | — | 1.348489540060868 |
| resonance:resonances | `phif0_980.Amplitude.const1` | 0.1 | True | — | 0.0 |
| resonance:resonances | `phif0_980.Amplitude.const2` | 0.1065182971468388 | False | — | 0.003833456119689838 |
| resonance:resonances | `phif0_980.Amplitude.theta1` | 0.1 | True | — | 0.0 |
| resonance:resonances | `phif0_980.Amplitude.theta2` | 0.03807025376236671 | False | — | 0.0032382807585900437 |
| resonance:resonances | `phif0_1710.propagators.A_propagator.mass` | 1.02 | True | — | — |
| resonance:resonances | `phif0_1710.propagators.A_propagator.width` | 0.004 | True | — | — |
| resonance:resonances | `phif0_1710.propagators.B_propagator.mass` | 1.6761965590304995 | False | [1.704, 1.0] | 0.008608254171218993 |
| resonance:resonances | `phif0_1710.propagators.B_propagator.width` | 0.16270071108440043 | False | [0.123, 1.0] | 0.007928828044131218 |
| resonance:resonances | `phif0_1710.Amplitude.const1` | 0.02201375198386279 | False | — | 0.0028493281809777366 |
| resonance:resonances | `phif0_1710.Amplitude.const2` | 0.007433204877151768 | False | — | 0.0027873338673183225 |
| resonance:resonances | `phif0_1710.Amplitude.theta1` | 0.008302300118288414 | False | — | 0.003420832265462995 |
| resonance:resonances | `phif0_1710.Amplitude.theta2` | -0.018544178045626723 | False | — | 0.002285070372617045 |
| resonance:resonances | `phif2_1270.propagators.A_propagator.mass` | 1.02 | True | — | — |
| resonance:resonances | `phif2_1270.propagators.A_propagator.width` | 0.004 | True | — | — |
| resonance:resonances | `phif2_1270.propagators.B_propagator.mass` | 1.2896149318644679 | False | [1.2755, 1.0] | 0.008900150561499074 |
| resonance:resonances | `phif2_1270.propagators.B_propagator.width` | 0.1959796900380022 | False | [0.1867, 1.0] | 0.009003877508753227 |
| resonance:resonances | `phif2_1270.Amplitude.const1` | -0.013533706721054747 | False | — | 0.013059446776572923 |
| resonance:resonances | `phif2_1270.Amplitude.const2` | -0.01650921272412254 | False | — | 0.011103610207449996 |
| resonance:resonances | `phif2_1270.Amplitude.const3` | 0.015339403283337268 | False | — | 0.007598401439603328 |
| resonance:resonances | `phif2_1270.Amplitude.const4` | 0.029798824827026338 | False | — | 0.013596613875924366 |
| resonance:resonances | `phif2_1270.Amplitude.const5` | 0.020982478502465995 | False | — | 0.011084121094273973 |
| resonance:resonances | `phif2_1270.Amplitude.theta1` | 0.05458389002821978 | False | — | 0.010607053111143525 |
| resonance:resonances | `phif2_1270.Amplitude.theta2` | 0.016032334798079934 | False | — | 0.009620235767829567 |
| resonance:resonances | `phif2_1270.Amplitude.theta3` | 0.017179622009723918 | False | — | 0.008259678006502619 |
| resonance:resonances | `phif2_1270.Amplitude.theta4` | -0.050143087437086675 | False | — | 0.010731665771685451 |
| resonance:resonances | `phif2_1270.Amplitude.theta5` | -0.008718872479379924 | False | — | 0.009363006763018657 |
| resonance:resonances | `phif2_1525.propagators.A_propagator.mass` | 1.02 | True | — | — |
| resonance:resonances | `phif2_1525.propagators.A_propagator.width` | 0.004 | True | — | — |
| resonance:resonances | `phif2_1525.propagators.B_propagator.mass` | 1.5222602842746435 | False | [1.517, 1.0] | 0.0021852818767245097 |
| resonance:resonances | `phif2_1525.propagators.B_propagator.width` | 0.08576525399315078 | False | [0.086, 1.0] | 0.004480554483528854 |
| resonance:resonances | `phif2_1525.Amplitude.const1` | -0.005345214125595505 | False | — | 0.002361030920067052 |
| resonance:resonances | `phif2_1525.Amplitude.const2` | 0.0031770703345810553 | False | — | 0.0022601284491659272 |
| resonance:resonances | `phif2_1525.Amplitude.const3` | -0.0036743677603351056 | False | — | 0.0018391542634132708 |
| resonance:resonances | `phif2_1525.Amplitude.const4` | 0.004813366936315499 | False | — | 0.0034476100080681558 |
| resonance:resonances | `phif2_1525.Amplitude.const5` | 0.010000673114238258 | False | — | 0.0024458295985315373 |
| resonance:resonances | `phif2_1525.Amplitude.theta1` | -0.010529063356530807 | False | — | 0.002019182721147269 |
| resonance:resonances | `phif2_1525.Amplitude.theta2` | 0.003910028530572422 | False | — | 0.0014883832205133188 |
| resonance:resonances | `phif2_1525.Amplitude.theta3` | 0.0031787953173277725 | False | — | 0.0009832831099109687 |
| resonance:resonances | `phif2_1525.Amplitude.theta4` | 0.0333658928584713 | False | — | 0.0037659511330376417 |
| resonance:resonances | `phif2_1525.Amplitude.theta5` | -0.006053516058970728 | False | — | 0.0016345295470368193 |
| resonance:resonances | `phif2_2150.propagators.A_propagator.mass` | 1.02 | True | — | — |
| resonance:resonances | `phif2_2150.propagators.A_propagator.width` | 0.004 | True | — | — |
| resonance:resonances | `phif2_2150.propagators.B_propagator.mass` | 2.1619576785269476 | False | [2.157, 1.0] | 0.009091748268572158 |
| resonance:resonances | `phif2_2150.propagators.B_propagator.width` | 0.15906049251159413 | False | [0.152, 1.0] | 0.009061189535661485 |
| resonance:resonances | `phif2_2150.Amplitude.const1` | 0.004643720949518616 | False | — | 0.004293173395970161 |
| resonance:resonances | `phif2_2150.Amplitude.const2` | -0.0009682564746806725 | False | — | 0.004579214352357212 |
| resonance:resonances | `phif2_2150.Amplitude.const3` | -0.0029804674908844213 | False | — | 0.0025923332971131054 |
| resonance:resonances | `phif2_2150.Amplitude.const4` | 0.008315390493289363 | False | — | 0.004795045874173534 |
| resonance:resonances | `phif2_2150.Amplitude.const5` | 0.0005819695034846763 | False | — | 0.004151013688821708 |
| resonance:resonances | `phif2_2150.Amplitude.theta1` | 0.00545992748088964 | False | — | 0.003178818200828604 |
| resonance:resonances | `phif2_2150.Amplitude.theta2` | -0.012498776031677225 | False | — | 0.004094191659114589 |
| resonance:resonances | `phif2_2150.Amplitude.theta3` | 0.002196563552197887 | False | — | 0.0024912191401879813 |
| resonance:resonances | `phif2_2150.Amplitude.theta4` | -0.016814307435916394 | False | — | 0.0032647649405574786 |
| resonance:resonances | `phif2_2150.Amplitude.theta5` | -0.007232946300343621 | False | — | 0.003910253340981285 |
| resonance:resonances | `phif2_2340.propagators.A_propagator.mass` | 1.02 | True | — | — |
| resonance:resonances | `phif2_2340.propagators.A_propagator.width` | 0.004 | True | — | — |
| resonance:resonances | `phif2_2340.propagators.B_propagator.mass` | 2.547889297662712 | False | [2.345, 0.01] | 0.025714265576588485 |
| resonance:resonances | `phif2_2340.propagators.B_propagator.width` | 0.324001266488012 | False | [0.322, 1.0] | 0.008869958469754202 |
| resonance:resonances | `phif2_2340.Amplitude.const1` | -0.15266341362240637 | False | — | 0.0226276447864268 |
| resonance:resonances | `phif2_2340.Amplitude.const2` | -0.05030214288962155 | False | — | 0.01462254664631181 |
| resonance:resonances | `phif2_2340.Amplitude.const3` | -0.01856511044577769 | False | — | 0.01602693686543622 |
| resonance:resonances | `phif2_2340.Amplitude.const4` | 0.0908719088071242 | False | — | 0.015326282883084562 |
| resonance:resonances | `phif2_2340.Amplitude.const5` | 0.029544599934778714 | False | — | 0.014428141030373473 |
| resonance:resonances | `phif2_2340.Amplitude.theta1` | 0.06277085590848677 | False | — | 0.01543028339321429 |
| resonance:resonances | `phif2_2340.Amplitude.theta2` | -0.0031366601030189344 | False | — | 0.01485537124391433 |
| resonance:resonances | `phif2_2340.Amplitude.theta3` | 0.13756083806604205 | False | — | 0.015675234074991284 |
| resonance:resonances | `phif2_2340.Amplitude.theta4` | -0.0033564526519642953 | False | — | 0.01289703559343365 |
| resonance:resonances | `phif2_2340.Amplitude.theta5` | 0.06849361819185686 | False | — | 0.016369611794000778 |
| resonance:resonances | `phif0_2470.propagators.A_propagator.mass` | 1.02 | True | — | — |
| resonance:resonances | `phif0_2470.propagators.A_propagator.width` | 0.004 | True | — | — |
| resonance:resonances | `phif0_2470.propagators.B_propagator.mass` | 2.57497529295397 | False | [2.47, 0.007] | 0.00489289053639705 |
| resonance:resonances | `phif0_2470.propagators.B_propagator.width` | 0.15761784400243628 | False | [0.075, 0.011] | 0.008657054415984383 |
| resonance:resonances | `phif0_2470.Amplitude.const1` | -0.345074426966773 | False | — | 0.01955694586578195 |
| resonance:resonances | `phif0_2470.Amplitude.const2` | -0.15428119408751656 | False | — | 0.014870979855746012 |
| resonance:resonances | `phif0_2470.Amplitude.theta1` | 0.2290031973516395 | False | — | 0.010330891827371173 |
| resonance:resonances | `phif0_2470.Amplitude.theta2` | -0.13412740539296167 | False | — | 0.01384041134802183 |
