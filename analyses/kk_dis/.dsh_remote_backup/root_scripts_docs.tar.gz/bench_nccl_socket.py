"""
NCCL_SOCKET_IFNAME multi-node benchmark over Ethernet.

Correctness + bandwidth measurement of cross-process all-reduce using JAX
NamedSharding (the pattern that triggers automatic NVIDIA/NCCL all-reduce).
Each process owns a local shard and contributes to the global sum; we time it
to estimate effective socket bandwidth.

Usage (header node, process 0):
    docker run --rm --gpus all --network=host \
        -e JAX_COORDINATOR_ADDRESS=192.168.200.171:12345 \
        -e JAX_NUM_PROCESSES=2 \
        -e JAX_PROCESS_ID=0 \
        -e NCCL_SOCKET_IFNAME=enp5s0 \
        -v <dir>:/workspace/work -w /workspace/work \
        jax-fit:latest /opt/env/bin/python bench_nccl_socket.py

Worker node (process 1):
    docker run --rm --gpus all --network=host \
        -e JAX_COORDINATOR_ADDRESS=192.168.200.171:12345 \
        -e JAX_NUM_PROCESSES=2 \
        -e JAX_PROCESS_ID=1 \
        -e NCCL_SOCKET_IFNAME=enp4s0 \
        ...
"""
import os
import time

import jax
import jax.numpy as jnp
from jax.sharding import Mesh, NamedSharding, PartitionSpec as P


def init_distributed():
    coordinator = os.environ.get("JAX_COORDINATOR_ADDRESS", "")
    num_processes = int(os.environ.get("JAX_NUM_PROCESSES", 1))
    process_id = int(os.environ.get("JAX_PROCESS_ID", 0))
    if num_processes > 1:
        jax.distributed.initialize(
            coordinator_address=coordinator,
            num_processes=num_processes,
            process_id=process_id,
        )
    return num_processes, process_id


def basic_info(num_processes, process_id):
    print(f"[P{process_id}/{num_processes}] local_devices={jax.local_devices()}", flush=True)
    print(f"[P{process_id}/{num_processes}] device_count={jax.device_count()} "
          f"local_device_count={jax.local_device_count()}", flush=True)
    print(f"[P{process_id}/{num_processes}] coord={os.environ.get('JAX_COORDINATOR_ADDRESS')} "
          f"iface={os.environ.get('NCCL_SOCKET_IFNAME')}", flush=True)


def allreduce_sum(num_processes, process_id):
    """Correctness: each process contributes (process_id+1); global sum must equal expected."""
    devices = jax.devices()
    mesh = Mesh(devices, ("devices",))
    num_local = jax.local_device_count()
    local_data = jnp.full((num_local,), float(process_id + 1))
    sharding = NamedSharding(mesh, P("devices",))
    out_sharding = NamedSharding(mesh, P())
    global_arr = jax.make_array_from_process_local_data(sharding, local_data)
    result = jax.jit(jnp.sum, in_shardings=sharding, out_shardings=out_sharding)(global_arr)
    expected = float(sum(i + 1 for i in range(num_processes)) * num_local)
    actual = float(result)
    ok = abs(actual - expected) < 1e-5
    print(f"[P{process_id}] allreduce_sum: local={float(process_id+1):.1f} "
          f"sum={actual:.1f} expected={expected:.1f} {'PASS' if ok else 'FAIL'}", flush=True)
    return ok


def bench_allreduce(num_processes, process_id, sizes=(2**20, 2**22, 2**24, 2**26), iters=20, warmup=5):
    """Time a cross-process all-reduce of a replicated-array of N float32 elements.

    We put the same (replicated) array on every device via a Mesh and use
    shard_map to psum over the mesh axis -> a real NCCL all-reduce across the
    2 processes. Bytes moved per process = N * 4 (each process's contribution).
    """
    devices = jax.devices()
    mesh = Mesh(devices, ("devices",))
    from jax.experimental.shard_map import shard_map
    from functools import partial

    def _psum(x):
        return shard_map(
            partial(jax.lax.psum, axis_name="devices"),
            mesh=mesh,
            in_specs=P(),
            out_specs=P(),
        )(x)

    print("\n--- allreduce bandwidth (NCCL socket) ---", flush=True)
    print(f"{'bytes':>12} {'MB':>10} {'time_ms':>10} {'GB/s':>9} {'kind':>8}", flush=True)
    results = {}
    for n in sizes:
        arr = jnp.full((num_processes * jax.local_device_count(), n), 1.0, dtype=jnp.float32)
        arr = jax.device_put(arr, NamedSharding(mesh, P()))

        f = jax.jit(_psum)
        for _ in range(warmup):
            f(arr).block_until_ready()

        times = []
        data_per_proc = n * 4  # bytes in this process's shard
        for _ in range(iters):
            t0 = time.perf_counter()
            f(arr).block_until_ready()
            t1 = time.perf_counter()
            times.append(t1 - t0)
        tmin = min(times)
        total_bytes = data_per_proc * num_processes
        gbps = total_bytes / tmin / 1e9
        mb = data_per_proc / (1024 * 1024)
        results[n] = gbps
        print(f"{n:>12} {mb:>10.1f} {tmin*1000:>10.2f} {gbps:>9.3f} {'allreduce':>8}", flush=True)
    return results


def main():
    num_processes, process_id = init_distributed()
    print(f"\n{'='*58}\nJAX multi-node NCCL socket benchmark  (JAX {jax.__version__})\n{'='*58}", flush=True)
    basic_info(num_processes, process_id)

    ok = allreduce_sum(num_processes, process_id)
    bench_allreduce(num_processes, process_id)

    if num_processes > 1:
        jax.distributed.barrier()
    print(f"\n[P{process_id}] Done. allreduce_sum={'PASS' if ok else 'FAIL'}", flush=True)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
