#!/usr/bin/env bash
# kk_dis distributed fit launcher: coordinator (P0, HEP3) + worker (P1, HEP1).
# Usage: run_dist_fit.sh <outdir>
set -u
SSH="ssh -F /dev/null -o BatchMode=yes -o ConnectTimeout=25 -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile=/tmp/dsh_probe_known_hosts"
IMG="jax-fit:latest"
COORD="192.168.200.171:12345"
TMO=500
OUTDIR="$1"
SCRIPT="run/fit_script_dist.py"
TRACE="~/dist_compare_fit.log"

echo "[launcher] cleanup"
$SSH hyx@192.168.200.171 'docker rm -f $(docker ps -aq) >/dev/null 2>&1; echo "hep3 cleaned"' 2>&1
docker rm -f $(docker ps -aq) >/dev/null 2>&1 || true
echo "[launcher] hep1 cleaned"

echo "[launcher] starting coordinator on HEP3 ..."
$SSH hyx@192.168.200.171 "cd ~/kk_dis_build && setsid nohup docker run --rm --gpus all --network=host \
  -e CUDA_VISIBLE_DEVICES=0 -e JAX_COORDINATOR_ADDRESS=${COORD} -e JAX_NUM_PROCESSES=2 -e JAX_PROCESS_ID=0 \
  -e NCCL_SOCKET_IFNAME=enp5s0 -e JAX_COORDINATOR_TIMEOUT=${TMO} -e KKDIS_OUTDIR=${OUTDIR} \
  -v ~/kk_dis_build:/workspace/work -w /workspace/work ${IMG} /opt/env/bin/python ${SCRIPT} \
  > ${TRACE} 2>&1 < /dev/null & echo coord-started" 2>&1

echo "[launcher] waiting for coordinator port ..."
for i in $(seq 1 25); do
  sleep 3
  if $SSH hyx@192.168.200.171 'ss -ltn 2>/dev/null | grep -q 12345' >/dev/null 2>&1; then
    echo "[launcher] coordinator LISTENING after $((i*3))s"
    break
  fi
done
$SSH hyx@192.168.200.171 'ss -ltn 2>/dev/null | grep 12345 || echo "coordinator-pending"' 2>&1

echo "[launcher] starting worker on HEP1 ..."
cd ~/LLMPWA/kk_dis && setsid nohup docker run --rm --gpus all --network=host \
  -e CUDA_VISIBLE_DEVICES=0 -e JAX_COORDINATOR_ADDRESS="$COORD" -e JAX_NUM_PROCESSES=2 -e JAX_PROCESS_ID=1 \
  -e NCCL_SOCKET_IFNAME=enp4s0 -e JAX_COORDINATOR_TIMEOUT="$TMO" -e KKDIS_OUTDIR="$OUTDIR" \
  -v ~/LLMPWA/kk_dis:/workspace/work -w /workspace/work "$IMG" /opt/env/bin/python "$SCRIPT" \
  > /tmp/hep1_cross_fit.log 2>&1 < /dev/null &
echo "[launcher] both launched"
