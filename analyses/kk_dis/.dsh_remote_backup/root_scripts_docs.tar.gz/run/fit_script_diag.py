"""诊断v2:验证 Newton-CG 的 CG 子迭代是否在两端分叉。
打印每次外迭代后累计的 objective/jac/hessp 调用次数,以及 when nll 输出。
跑一小段(设 maxiter=26,即卡点之前),对比两端累计次数是否一致。
"""
import os
import sys
import contextlib

_here = os.path.dirname(os.path.abspath(__file__))
_root = os.path.dirname(_here)
os.chdir(_root)
for p in (_root, _here):
    if p not in sys.path:
        sys.path.insert(0, p)
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
import jax.numpy as jnp
import numpy as onp
from jax import config, device_put, grad, jit, jvp
from jax.sharding import Mesh, NamedSharding, PartitionSpec as P
from scipy.optimize import minimize

from base_functions import load_data, make_initial_args, normalize_data, shard_data_distributed
from likelihood_function import make_distributed_likelihood


def main():
    coordinator = os.environ.get("JAX_COORDINATOR_ADDRESS", "")
    num_processes = int(os.environ.get("JAX_NUM_PROCESSES", 1))
    process_id = int(os.environ.get("JAX_PROCESS_ID", 0))
    if num_processes > 1:
        jax.distributed.initialize(coordinator_address=coordinator,
                                    num_processes=num_processes, process_id=process_id)
    is_chief = process_id == 0
    config.update("jax_enable_x64", True)

    data = normalize_data(load_data())
    data_size = int(data["data_phi_kk"].shape[0])
    mesh = Mesh(jax.devices(), axis_names=("event",))
    initial_args, _, _ = make_initial_args()
    replicated = NamedSharding(mesh, P())

    ctx = jax.set_mesh(mesh) if hasattr(jax, "set_mesh") else contextlib.nullcontext()
    with ctx:
        jax_data = shard_data_distributed(data, mesh)
        nll = make_distributed_likelihood(data_size)
        grad_nll = grad(nll, argnums=0)

        def hvp_nll(args, vector, data_arg):
            zero_data = jax.tree_util.tree_map(jnp.zeros_like, data_arg)
            return jvp(lambda a, d: grad_nll(a, d), (args, data_arg), (vector, zero_data))[1]

        jit_nll = jit(nll)
        jit_grad = jit(grad_nll)
        jit_hvp = jit(hvp_nll)

        def replicated_array(v):
            return device_put(jnp.asarray(v), replicated)

        x0 = replicated_array(initial_args)
        d0 = replicated_array(onp.zeros_like(initial_args))
        smoke = jit_nll(x0, jax_data)
        counts = {"obj": 0, "jac": 0, "hessp": 0}

        def objective(x):
            counts["obj"] += 1
            return float(jit_nll(replicated_array(x), jax_data))

        def gradient_value(x):
            counts["jac"] += 1
            return onp.asarray(jit_grad(replicated_array(x), jax_data), dtype=onp.float64)

        def hessian_vector(x, vector):
            counts["hessp"] += 1
            return onp.asarray(jit_hvp(replicated_array(x), replicated_array(vector), jax_data),
                               dtype=onp.float64)

        it = [0]
        def callback(xk):
            it[0] += 1
            # 每个外迭代末尾打印累计次数 (两端都会打印,方便对比)
            print(f"[P{process_id}] it{it[0]} iter_end counts obj={counts['obj']} "
                  f"jac={counts['jac']} hessp={counts['hessp']}", flush=True)

        # 跑到卡点 26 之后 (maxiter=28),看两端计数在哪一行分叉
        result = minimize(
            objective, x0=onp.asarray(initial_args, dtype=onp.float64),
            jac=gradient_value, hessp=hessian_vector, method="Newton-CG",
            callback=callback, options={"disp": False, "maxiter": 28, "xtol": 1e-8},
        )
        print(f"[P{process_id}] DIAG_END success={result.success} nll={float(result.fun):.8f} "
              f"final_counts obj={counts['obj']} jac={counts['jac']} hessp={counts['hessp']} "
              f"nit={result.nit}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
