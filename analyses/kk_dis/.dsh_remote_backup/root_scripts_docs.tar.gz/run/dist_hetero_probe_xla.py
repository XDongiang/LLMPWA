#!/usr/bin/env python
"""Pure-XLA collective layer under heterogeneous local devices (2 vs 1).

Does NOT call multihost_utils and does NOT use device_put(NamedSharding) which
triggers its assert. Uses explicit per-device placement + jax.lax.psum to test
whether the XLA/collective layer itself tolerates 3 devices split as 2+1.
"""
import os
import sys
import time

import jax
import numpy as np
import jax.numpy as jnp

pid = int(sys.argv[1])
coordinator = sys.argv[2]
num_processes = int(sys.argv[3])

jax.distributed.initialize(
    coordinator_address=coordinator,
    num_processes=num_processes,
    process_id=pid,
)
print(f"[p{pid}] local={len(jax.local_devices())} global={len(jax.devices())}", flush=True)
time.sleep(8)  # both processes must be past initialize

from jax.sharding import Mesh, PartitionSpec as P

mesh = Mesh(jax.devices(), axis_names=("event",))

# 1) place a 1D array ONCE per device explicitly (no NamedSharding machinery)
devices = list(jax.local_devices())
n_local = len(devices)
chunk = np.arange(10000, dtype=np.float64) + pid * 100000.0
shards = [jax.device_put(chunk, d) for d in devices]  # each device gets full copy here
print(f"[p{pid}] explicit device_put per local device OK (n={n_local})", flush=True)

# 2) psum reduction across ALL global devices via shard_map (no multihost_utils)
from jax.sharding import Mesh, NamedSharding, PartitionSpec as P
import jax

mesh = Mesh(jax.devices(), axis_names=("event",))
from jax.experimental.shard_map import shard_map

@jax.jit
def f(x):
    return jax.lax.psum(jnp.sum(x), "event")

try:
    g = shard_map(
        lambda x: jax.lax.psum(jnp.sum(x), "event"),
        mesh=mesh,
        in_specs=P("event", None),
        out_specs=P(),
    )
    x = jnp.arange(30000, dtype=jnp.float32).reshape(30000, 1)
    r = g(x)
    print(f"[p{pid}] shard_map psum over {len(jax.devices())} global devs OK sum={float(r):.0f}", flush=True)
except Exception as e:
    print(f"[p{pid}] shard_map psum: {type(e).__name__}: {str(e)[:200]}", flush=True)

jax.distributed.shutdown()
print(f"[p{pid}] DONE", flush=True)
