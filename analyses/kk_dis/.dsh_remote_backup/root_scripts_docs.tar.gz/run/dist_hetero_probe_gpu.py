#!/usr/bin/env python
"""Cross-node heterogeneous-GPU JAX probe (HEP1: 2 GPUs as proc0, HEP3: 1 GPU as proc1).

Runs inside the jax-fit container with --gpus all (NO CUDA_VISIBLE_DEVICES mask):
one JAX process per node, each process owns all local GPUs.
Answers:
  1. does jax.distributed initialize with asymmetric local device counts (2 vs 1)?
  2. does sharding an event axis of 30000 (divisible by 3) work in that topology?
  3. does broadcast_one_to_all / chief-worker request loop work?
"""
import os
import sys
import time

import jax
import numpy as np

pid = int(sys.argv[1])
coordinator = sys.argv[2]
num_processes = int(sys.argv[3])

jax.distributed.initialize(
    coordinator_address=coordinator,
    num_processes=num_processes,
    process_id=pid,
)
print(f"[p{pid}] local={len(jax.local_devices())} global={len(jax.devices())}", flush=True)
# brief staggered start (both processes must initialize before device_put)
time.sleep(5)

from jax.sharding import Mesh, NamedSharding, PartitionSpec as P

mesh = Mesh(jax.devices(), axis_names=("event",))
arr = np.arange(30000, dtype=np.float64)
sh = jax.device_put(arr, NamedSharding(mesh, P("event")))
if pid == 0:
    print(f"[p0] device_put 30000 events on mesh of {len(jax.devices())} devices OK: "
          f"local_shard={len(np.asarray(jax.device_get(sh)))}", flush=True)

from jax.experimental import multihost_utils

# request/response loop, chief (pid 0) drives
if pid == 0:
    total = float(multihost_utils.broadcast_one_to_all({"x": np.float64(1.0)})["x"])
    print(f"[p0] broadcast_one_to_all OK recv={total}", flush=True)
else:
    total = float(multihost_utils.broadcast_one_to_all({"x": np.float64(2.0)})["x"])
    print(f"[p1] broadcast_one_to_all OK recv={total}", flush=True)

jax.distributed.shutdown()
print(f"[p{pid}] DONE", flush=True)
