"""
Fit-cost timing benchmark: measures the wall-clock of the operations that
dominate a Newton-CG fit iteration (objective, gradient, HVP) so we can compare
single-node vs distributed (NCCL socket) and see the actual overhead.

Runs the REAL likelihood/gradient/HVP from the kk_dis pipeline, just like
fit_script.py, but times each call and optionally limits the iterations.

Usage (single node):
    docker run --rm --gpus all --network=host \
        -e JAX_NUM_PROCESSES=1 -e JAX_PROCESS_ID=0 \
        -v ~/kk_dis_build:/workspace/work -w /workspace/work \
        jax-fit:latest /opt/env/bin/python time_fit_iter.py --iters 3

Usage (distributed): set JAX_COORDINATOR_ADDRESS / JAX_NUM_PROCESSES / JAX_PROCESS_ID
    Coordinator (process 0) and worker (process 1) both run this; per-call wall
    clocks are printed on process 0.
"""
import argparse
import contextlib
import os
import sys
import time

_root = os.path.dirname(os.path.abspath(__file__))  # script lives at analysis root
_run = os.path.join(_root, "run")
os.chdir(_root)
for p in (_root, _run):
    if p not in sys.path:
        sys.path.insert(0, p)
os.environ.setdefault("XLA_PYTHON_CLIENT_PREALLOCATE", "false")

import jax
import jax.numpy as jnp
import numpy as onp
from jax import config, device_put, grad, jit, jvp
from jax.sharding import Mesh, NamedSharding, PartitionSpec as P

from base_functions import (
    load_data,
    make_initial_args,
    normalize_data,
    shard_data_distributed,
)
from likelihood_function import make_distributed_likelihood


def init_distributed():
    coordinator = os.environ.get("JAX_COORDINATOR_ADDRESS", "")
    num_processes = int(os.environ.get("JAX_NUM_PROCESSES", 1))
    process_id = int(os.environ.get("JAX_PROCESS_ID", 0))
    if num_processes > 1:
        jax.distributed.initialize(
            coordinator_address=coordinator,
            num_processes=num_processes,
            process_id=process_id,
        )
    return num_processes, process_id


def build_mesh():
    return Mesh(jax.devices(), axis_names=("event",))


def _mesh_context(mesh):
    if hasattr(jax, "set_mesh"):
        return jax.set_mesh(mesh)
    return contextlib.nullcontext()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--iters", type=int, default=5, help="number of timed iterations")
    parser.add_argument("--smoke-only", action="store_true", help="just run one likelihood")
    args = parser.parse_args()

    num_processes, process_id = init_distributed()
    is_chief = process_id == 0
    config.update("jax_enable_x64", True)

    data = normalize_data(load_data())
    data_size = int(data["data_phi_kk"].shape[0])
    mesh = build_mesh()
    initial_args, _, _ = make_initial_args()
    replicated = NamedSharding(mesh, P())

    with _mesh_context(mesh):
        jax_data = shard_data_distributed(data, mesh)
        nll = make_distributed_likelihood(data_size)
        grad_nll = grad(nll, argnums=0)

        def hvp_nll(args, vector, data_arg):
            zero_data = jax.tree_util.tree_map(jnp.zeros_like, data_arg)
            return jvp(
                lambda a, d: grad_nll(a, d),
                (args, data_arg),
                (vector, zero_data),
            )[1]

        jit_nll = jit(nll)
        jit_grad = jit(grad_nll)
        jit_hvp = jit(hvp_nll)

        def replicated_array(value):
            return device_put(jnp.asarray(value), replicated)

        x0 = replicated_array(initial_args)
        direction0 = replicated_array(onp.zeros_like(initial_args))
        vec_eye = replicated_array(onp.eye(initial_args.size, dtype=onp.float64)[:, 0])

        # Warmup + correctness smoke
        t_s = time.perf_counter()
        smoke_value = jit_nll(x0, jax_data)
        smoke_value.block_until_ready()
        t_smoke = time.perf_counter() - t_s

        if args.smoke_only:
            if is_chief:
                print(f"[P{process_id}] smoke nll={float(smoke_value):.6f} "
                      f"data_size={data_size} n_params={initial_args.size} "
                      f"time={t_smoke*1000:.1f}ms", flush=True)
            return 0

        # Time objective, gradient, and one HVP over `iters` calls each
        times = {"objective": [], "gradient": [], "hvp": []}

        def time_calls(fn, label, *call_args, n=args.iters):
            # BOTH processes issue the SAME number of collectives (1 warmup + n),
            # otherwise the NCCL collectives fall out of sync and deadlock.
            # warmup (1 collective)
            fn(*call_args).block_until_ready()
            for _ in range(n):
                if not is_chief:
                    # worker: participate but don't report
                    fn(*call_args).block_until_ready()
                else:
                    t0 = time.perf_counter()
                    out = fn(*call_args)
                    out.block_until_ready()
                    dt = time.perf_counter() - t0
                    times[label].append(dt)

        time_calls(lambda a, d: jit_nll(a, d), "objective", x0, jax_data)
        time_calls(lambda a, d: jit_grad(a, d), "gradient", x0, jax_data)
        time_calls(lambda a, v, d: jit_hvp(a, v, d), "hvp", x0, vec_eye, jax_data)

        if is_chief:
            def report(label):
                ts = times[label]
                if not ts:
                    return
                mean = onp.mean(ts)
                p50 = onp.percentile(ts, 50)
                print(f"[P{process_id}] {label:12s} mean={mean*1000:8.1f}ms "
                      f"p50={p50*1000:8.1f}ms min={min(ts)*1000:8.1f}ms "
                      f"max={max(ts)*1000:8.1f}ms  (n={len(ts)})", flush=True)

            print(f"\n[P{process_id}] processes={num_processes} devices={len(jax.devices())} "
                  f"local_devices={len(jax.local_devices())} n_params={initial_args.size} "
                  f"data_size={data_size}", flush=True)
            print(f"[P{process_id}] smoke nll={float(smoke_value):.6f} "
                  f"smoke_time={t_smoke*1000:.1f}ms", flush=True)
            report("objective")
            report("gradient")
            report("hvp")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
