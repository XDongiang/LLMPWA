#!/usr/bin/env bash
# Runs the coordinator (process 0) for kk_dis distributed fit on HEP3.
set -u
cd ~/kk_dis_build
docker run --rm --gpus all --network=host \
  -e CUDA_VISIBLE_DEVICES=0 \
  -e JAX_COORDINATOR_ADDRESS=192.168.200.171:12345 \
  -e JAX_NUM_PROCESSES=2 -e JAX_PROCESS_ID=0 \
  -e NCCL_SOCKET_IFNAME=enp5s0 -e JAX_COORDINATOR_TIMEOUT=500 \
  -e KKDIS_OUTDIR=compare/dist_base \
  -v ~/kk_dis_build:/workspace/work -w /workspace/work \
  jax-fit:latest /opt/env/bin/python run/fit_script_dist.py \
  > ~/dist_compare_fit.log 2>&1
